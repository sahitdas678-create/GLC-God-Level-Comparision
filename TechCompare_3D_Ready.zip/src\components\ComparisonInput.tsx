import React from "react";
import { ArrowLeftRight, Globe, Sparkles, Laptop, Smartphone, Zap, Box, Compass } from "lucide-react";

interface ComparisonInputProps {
  product1: string;
  setProduct1: (val: string) => void;
  product2: string;
  setProduct2: (val: string) => void;
  region: string;
  setRegion: (val: string) => void;
  onCompare: () => void;
  loading: boolean;
}

const REGIONS = [
  { label: "🇮🇳 India (INR, ₹)", value: "India (INR, ₹)" },
  { label: "🇺🇸 United States (USD, $)", value: "United States (USD, $)" },
  { label: "🇬🇧 United Kingdom (GBP, £)", value: "United Kingdom (GBP, £)" },
  { label: "🇪🇺 Europe (EUR, €)", value: "Europe (EUR, €)" },
  { label: "🇦🇺 Australia (AUD, A$)", value: "Australia (AUD, A$)" },
  { label: "🇨🇦 Canada (CAD, C$)", value: "Canada (CAD, C$)" },
  { label: "🇯🇵 Japan (JPY, ¥)", value: "Japan (JPY, ¥)" },
  { label: "🇦🇪 UAE (AED, د.إ)", value: "UAE (AED, د.إ)" },
];

const PRESETS = [
  { p1: "iPhone 17 Pro Max", p2: "Samsung Galaxy S26 Ultra", label: "Next-Gen Flagships", color: "cyan" },
  { p1: "iPhone 16 Pro Max", p2: "Samsung Galaxy S25 Ultra", label: "Current Flagships", color: "emerald" },
  { p1: "MacBook Pro 16 M4 Max", p2: "Dell XPS 16 (2025)", label: "Pro Laptops", color: "purple" },
  { p1: "NVIDIA RTX 5090", p2: "AMD Radeon RX 7900 XTX", label: "Flagship GPUs", color: "amber" },
  { p1: "Sony WH-1000XM5", p2: "Bose QuietComfort Ultra", label: "ANC Headphones", color: "rose" },
  { p1: "iPad Pro 13 (M4)", p2: "Samsung Galaxy Tab S10 Ultra", label: "Flagship Tablets", color: "blue" },
];

export function ComparisonInput({
  product1,
  setProduct1,
  product2,
  setProduct2,
  region,
  setRegion,
  onCompare,
  loading,
}: ComparisonInputProps) {
  const handleSwap = () => {
    const temp = product1;
    setProduct1(product2);
    setProduct2(temp);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && product1.trim() && product2.trim() && !loading) {
      onCompare();
    }
  };

  return (
    <div className="relative group/deck">
      {/* Main Card Deck */}
      <div className="relative bg-slate-900/90 backdrop-blur-2xl border border-slate-800 hover:border-cyan-500/40 rounded-2xl p-6 sm:p-8 shadow-sm transition-all duration-300">
        
        {/* Header Row */}
        <div className="text-center space-y-4 max-w-2xl mx-auto mb-8 pb-8 border-b border-slate-800">
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight leading-tight">
            Settle the debate <br className="hidden sm:block" />
            <span className="text-cyan-400">with data, not hype.</span>
          </h2>
          <p className="text-slate-400 text-sm sm:text-base px-4 font-medium">
            Full spec breakdowns, capability radar, and real regional pricing — settled by AI in seconds.
          </p>
        </div>

        {/* Input Fields Row with 3D Depth */}
        <div className="flex flex-col md:flex-row gap-3.5 items-center mb-6">
          {/* Product 1 Input */}
          <div className="w-full relative group">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-emerald-400">
                <Smartphone className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={product1}
                onChange={(e) => setProduct1(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Product A (e.g., iPhone 16 Pro Max)"
                disabled={loading}
                className="w-full pl-10 pr-4 py-3.5 bg-slate-950/80 border border-slate-700 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-500/20 rounded-xl outline-none transition-all placeholder:text-slate-500 text-white font-semibold text-sm disabled:opacity-50"
              />
              <span className="absolute top-2 right-2 text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/30">
                Unit A
              </span>
            </div>
          </div>

          {/* Swap Button */}
          <button
            type="button"
            onClick={handleSwap}
            title="Swap products"
            disabled={loading}
            className="w-10 h-10 shrink-0 rounded-xl bg-slate-900 border border-slate-700 text-cyan-400 hover:text-white hover:bg-slate-800 hover:border-cyan-400 flex items-center justify-center transition-all group cursor-pointer"
          >
            <ArrowLeftRight className="w-4 h-4 group-hover:rotate-180 transition-transform duration-300" />
          </button>

          {/* Product 2 Input */}
          <div className="w-full relative group">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-amber-400">
                <Laptop className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={product2}
                onChange={(e) => setProduct2(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Product B (e.g., Samsung Galaxy S25 Ultra)"
                disabled={loading}
                className="w-full pl-10 pr-4 py-3.5 bg-slate-950/80 border border-slate-700 focus:border-amber-400 focus:ring-2 focus:ring-amber-500/20 rounded-xl outline-none transition-all placeholder:text-slate-500 text-white font-semibold text-sm disabled:opacity-50"
              />
              <span className="absolute top-2 right-2 text-[10px] font-bold px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-500/30">
                Unit B
              </span>
            </div>
          </div>
        </div>

        {/* Region & Compare Button Controls */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-800/80">
          {/* Region selector */}
          <div className="w-full sm:w-auto flex items-center space-x-2">
            <div className="relative w-full sm:w-64">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                <Globe className="w-4 h-4" />
              </div>
              <select
                value={region}
                onChange={(e) => setRegion(e.target.value)}
                disabled={loading}
                className="w-full pl-9 pr-8 py-2.5 bg-slate-900 border border-slate-800 text-slate-200 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-cyan-500/20 focus:border-cyan-400 outline-none transition-all cursor-pointer hover:border-slate-700 appearance-none disabled:opacity-50 shadow-sm"
              >
                {REGIONS.map((r) => (
                  <option key={r.value} value={r.value} className="bg-slate-900 text-slate-200">
                    {r.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Solid Cyan Scan Button */}
          <button
            type="button"
            onClick={onCompare}
            disabled={loading || !product1.trim() || !product2.trim()}
            className="w-full sm:w-auto relative group overflow-hidden px-8 py-3.5 rounded-xl bg-cyan-400 hover:bg-cyan-500 text-slate-950 font-extrabold text-sm disabled:opacity-40 disabled:cursor-not-allowed transition-all transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer shadow-sm"
          >
            {/* Button Content */}
            <div className="relative flex items-center justify-center space-x-2">
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-slate-950/30 border-t-slate-950 rounded-full animate-spin" />
                  <span className="tracking-wide">Analyzing...</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 text-slate-950" />
                  <span className="tracking-wide">Compare Devices</span>
                </>
              )}
            </div>
          </button>
        </div>

        {/* Quick Matchups / Presets */}
        <div className="mt-6 pt-5 border-t border-slate-800/80">
          <div className="flex items-center space-x-2 mb-3">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest flex items-center space-x-1.5">
              <Compass className="w-3.5 h-3.5 text-cyan-400" />
              <span>Trending Flagship Matchups</span>
            </span>
          </div>
          <div className="flex flex-wrap gap-2.5">
            {PRESETS.map((preset, index) => (
              <button
                key={index}
                type="button"
                disabled={loading}
                onClick={() => {
                  setProduct1(preset.p1);
                  setProduct2(preset.p2);
                }}
                className="text-xs px-3.5 py-1.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-cyan-500/50 hover:bg-slate-800/90 text-slate-300 hover:text-white transition-all text-left flex items-center space-x-2 group disabled:opacity-40 cursor-pointer shadow-xs hover:shadow-[0_0_15px_rgba(6,182,212,0.2)]"
              >
                <span className="text-cyan-400 font-semibold group-hover:underline">{preset.p1}</span>
                <span className="text-slate-500 text-[10px] font-bold">vs</span>
                <span className="text-amber-400 font-semibold group-hover:underline">{preset.p2}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
