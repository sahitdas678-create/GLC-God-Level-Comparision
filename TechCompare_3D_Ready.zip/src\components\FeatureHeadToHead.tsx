import React, { useState } from "react";
import { ProductDetails } from "../types";
import {
  Check,
  Trophy,
  Minus,
  Cpu,
  Layers,
  HardDrive,
  Monitor,
  BatteryCharging,
  Camera,
  Weight,
  Sparkles,
  Info,
  ChevronDown,
  ChevronUp,
} from "lucide-react";

interface FeatureHeadToHeadProps {
  product1: ProductDetails;
  product2: ProductDetails;
  specWinners?: Record<string, "product1" | "product2" | "tie">;
  verdict: {
    winner: string;
    summary: string;
    product1Wins: string[];
    product2Wins: string[];
  };
}

export function FeatureHeadToHead({
  product1,
  product2,
  specWinners,
  verdict,
}: FeatureHeadToHeadProps) {
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [expandedRow, setExpandedRow] = useState<string | null>(null);

  const categories = [
    { id: "all", label: "Full Matrix" },
    { id: "core", label: "Silicon & Memory" },
    { id: "display", label: "Panel & Display" },
    { id: "battery", label: "Battery & Power" },
    { id: "camera", label: "Camera & Optics" },
  ];

  const getWinnerForSpec = (key: string, searchKey: string) => {
    if (specWinners && specWinners[key]) {
      return specWinners[key] === "product1" ? 1 : specWinners[key] === "product2" ? 2 : 0;
    }
    const regex = new RegExp(searchKey, "i");
    if (verdict.product1Wins.some((w) => regex.test(w))) return 1;
    if (verdict.product2Wins.some((w) => regex.test(w))) return 2;
    return 0;
  };

  const specsList = [
    {
      key: "processor",
      label: "Processor & Architecture",
      category: "core",
      icon: Cpu,
      val1: product1.specs.processor,
      val2: product2.specs.processor,
      winner: getWinnerForSpec("processor", "processor|cpu|chip|performance"),
      detail:
        "Microarchitecture node fabrication, sustained thermal limits, instruction set efficiency, and multicore cluster topology.",
    },
    {
      key: "ram",
      label: "Unified / System RAM",
      category: "core",
      icon: Layers,
      val1: product1.specs.ram,
      val2: product2.specs.ram,
      winner: getWinnerForSpec("ram", "ram|memory"),
      detail:
        "Memory bus bandwidth (GB/s), low-latency caching tiers, multitasking headroom, and AI weights buffering capacity.",
    },
    {
      key: "storage",
      label: "Storage Standard & Speed",
      category: "core",
      icon: HardDrive,
      val1: product1.specs.storage,
      val2: product2.specs.storage,
      winner: getWinnerForSpec("storage", "storage|nvme|ufs"),
      detail:
        "Sequential read/write speeds, NVMe vs UFS protocol overhead, cache hierarchy, and continuous video ingest rates.",
    },
    {
      key: "display",
      label: "Display Panel & Refresh",
      category: "display",
      icon: Monitor,
      val1: product1.specs.display,
      val2: product2.specs.display,
      winner: getWinnerForSpec("display", "display|screen|refresh|panel"),
      detail:
        "Peak HDR nits, variable refresh (1Hz-120Hz LTPO), subpixel matrix arrangement, and touch sampling latency.",
    },
    {
      key: "battery",
      label: "Battery Capacity & Charging",
      category: "battery",
      icon: BatteryCharging,
      val1: product1.specs.battery,
      val2: product2.specs.battery,
      winner: getWinnerForSpec("battery", "battery|charging|power|endurance"),
      detail:
        "Chemical degradation lifespan, thermal charging curves, watt-hour density, and active screen-on time endurance.",
    },
    {
      key: "camera",
      label: "Sensors & Optical Pipeline",
      category: "camera",
      icon: Camera,
      val1: product1.specs.camera,
      val2: product2.specs.camera,
      winner: getWinnerForSpec("camera", "camera|sensor|photo|zoom|periscope"),
      detail:
        "Sensor physical dimensions, aperture f-stops, optical image stabilization (OIS), and neural image processing engines.",
    },
    {
      key: "weight",
      label: "Chassis Weight & Materials",
      category: "display",
      icon: Weight,
      val1: product1.specs.weight,
      val2: product2.specs.weight,
      winner: getWinnerForSpec("weight", "weight|light|portable"),
      detail:
        "Structural aerospace-grade alloys, center of gravity balance, thermal heat sink dispersion, and daily pocket comfort.",
    },
  ];

  const filteredSpecs =
    activeCategory === "all"
      ? specsList
      : specsList.filter((s) => s.category === activeCategory);

  const toggleRow = (key: string) => {
    setExpandedRow(expandedRow === key ? null : key);
  };

  return (
    <div className="relative bg-[#0d121f]/90 backdrop-blur-2xl border border-slate-800/90 rounded-2xl overflow-hidden shadow-[0_20px_40px_rgba(0,0,0,0.8),inset_0_1px_0_0_rgba(255,255,255,0.08)]">
      {/* Header */}
      <div className="p-6 border-b border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/60">
        <div>
          <div className="flex items-center space-x-2">
            <Cpu className="w-5 h-5 text-cyan-400" />
            <h3 className="text-lg font-extrabold text-white">
              Direct Specification Matrix
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Side-by-side component breakdown with AI silicon architectural audit
          </p>
        </div>

        {/* Category Selector Tabs */}
        <div className="flex flex-wrap gap-1.5 p-1 bg-slate-950/80 rounded-xl border border-slate-800">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeCategory === cat.id
                  ? "bg-cyan-500 text-white shadow-[0_0_15px_rgba(6,182,212,0.4)]"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-900"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Comparison Table Header */}
      <div className="grid grid-cols-12 bg-slate-950/90 px-6 py-3.5 border-b border-slate-800 text-xs font-bold text-slate-400 uppercase tracking-wider">
        <div className="col-span-4 sm:col-span-3">Component / Spec</div>
        <div className="col-span-4 sm:col-span-4 text-emerald-400 truncate flex items-center space-x-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-sm" />
          <span>{product1.name}</span>
        </div>
        <div className="col-span-4 sm:col-span-4 text-amber-400 truncate flex items-center space-x-1.5">
          <span className="w-2 h-2 rounded-full bg-amber-400 shadow-sm" />
          <span>{product2.name}</span>
        </div>
        <div className="hidden sm:block sm:col-span-1 text-right">Advantage</div>
      </div>

      {/* Rows */}
      <div className="divide-y divide-slate-800/80">
        {filteredSpecs.map((spec) => {
          const Icon = spec.icon;
          const isExpanded = expandedRow === spec.key;

          return (
            <div
              key={spec.key}
              className="hover:bg-slate-900/50 transition-colors group cursor-pointer"
              onClick={() => toggleRow(spec.key)}
            >
              <div className="grid grid-cols-12 px-6 py-4 items-center">
                {/* Spec Label */}
                <div className="col-span-4 sm:col-span-3 pr-2">
                  <div className="flex items-center space-x-2">
                    <div className="w-7 h-7 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-cyan-400 shrink-0 shadow-inner">
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-xs font-bold text-slate-200 group-hover:text-cyan-300 transition-colors leading-tight">
                      {spec.label}
                    </span>
                  </div>
                </div>

                {/* Product 1 Value */}
                <div
                  className={`col-span-4 sm:col-span-4 pr-3 text-xs leading-relaxed ${
                    spec.winner === 1
                      ? "text-emerald-300 font-bold bg-emerald-950/30 p-2 rounded-lg border border-emerald-500/30"
                      : "text-slate-300"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span>{spec.val1 || "Standard Spec"}</span>
                    {spec.winner === 1 && (
                      <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 ml-1" />
                    )}
                  </div>
                </div>

                {/* Product 2 Value */}
                <div
                  className={`col-span-4 sm:col-span-4 pr-3 text-xs leading-relaxed ${
                    spec.winner === 2
                      ? "text-amber-300 font-bold bg-amber-950/30 p-2 rounded-lg border border-amber-500/30"
                      : "text-slate-300"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span>{spec.val2 || "Standard Spec"}</span>
                    {spec.winner === 2 && (
                      <Check className="w-3.5 h-3.5 text-amber-400 shrink-0 ml-1" />
                    )}
                  </div>
                </div>

                {/* Winner Pill */}
                <div className="hidden sm:flex sm:col-span-1 justify-end items-center space-x-1">
                  {spec.winner === 1 ? (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-500/40">
                      Unit A
                    </span>
                  ) : spec.winner === 2 ? (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-500/40">
                      Unit B
                    </span>
                  ) : (
                    <Minus className="w-4 h-4 text-slate-600" />
                  )}
                  {isExpanded ? (
                    <ChevronUp className="w-3.5 h-3.5 text-slate-500" />
                  ) : (
                    <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                  )}
                </div>
              </div>

              {/* Detailed Spec Drawer */}
              {isExpanded && (
                <div className="px-6 py-3 bg-slate-950/70 border-t border-slate-800/80 text-xs text-slate-400 flex items-start space-x-2">
                  <Info className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-200">Architectural Note:</strong> {spec.detail}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
