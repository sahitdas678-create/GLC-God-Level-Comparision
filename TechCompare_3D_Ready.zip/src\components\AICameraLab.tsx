import React, { useState, useEffect } from "react";
import {
  Camera,
  Moon,
  ZoomIn,
  Smile,
  SunMedium,
  CheckCircle2,
  Trophy,
  Sparkles,
  RefreshCw,
  Eye,
  Sliders,
} from "lucide-react";
import { ProductDetails, CameraScenario } from "../types";

interface AICameraLabProps {
  product1: ProductDetails;
  product2: ProductDetails;
}

export function AICameraLab({ product1, product2 }: AICameraLabProps) {
  const [scenarios, setScenarios] = useState<CameraScenario[]>([]);
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>("night");
  const [loading, setLoading] = useState(false);

  const fetchCameraShootout = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/camera-shootout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ product1, product2 }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.scenarios && Array.isArray(data.scenarios)) {
          setScenarios(data.scenarios);
          if (data.scenarios[0]) setSelectedScenarioId(data.scenarios[0].id);
        }
      }
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCameraShootout();
  }, [product1.name, product2.name]);

  const activeScenario = scenarios.find((s) => s.id === selectedScenarioId) || scenarios[0];

  const scenarioIcons: Record<string, React.ComponentType<{ className?: string }>> = {
    night: Moon,
    zoom: ZoomIn,
    portrait: Smile,
    hdr: SunMedium,
  };

  return (
    <div className="relative bg-[#0d121f]/90 backdrop-blur-2xl border border-slate-800/90 rounded-2xl p-4 sm:p-6 shadow-[0_20px_40px_rgba(0,0,0,0.8),inset_0_1px_0_0_rgba(255,255,255,0.08)] space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-purple-950/80 border border-purple-500/40 flex items-center justify-center shadow-[0_0_12px_rgba(168,85,247,0.3)]">
              <Camera className="w-4 h-4 text-purple-400" />
            </div>
            <h3 className="text-base font-extrabold text-white">
              AI Virtual Camera Shootout Lab
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Simulated optical benchmarks across 4 photographic shooting scenarios
          </p>
        </div>

        <button
          onClick={fetchCameraShootout}
          disabled={loading}
          className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-purple-950/60 text-purple-300 hover:bg-purple-900/60 border border-purple-500/40 text-xs font-semibold transition-all cursor-pointer disabled:opacity-50 shadow-[0_0_12px_rgba(168,85,247,0.2)]"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
          <span>Re-Simulate Optics</span>
        </button>
      </div>

      {/* Raw Sensor Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-800/40">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider">
              {product1.name} Optics
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded-md bg-emerald-950 text-emerald-300 border border-emerald-500/40 font-semibold">
              Primary System
            </span>
          </div>
          <p className="text-xs text-slate-200 font-medium leading-relaxed">
            {product1.specs.camera || "Advanced Multilens Array"}
          </p>
        </div>

        <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-800/40">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider">
              {product2.name} Optics
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded-md bg-amber-950 text-amber-300 border border-amber-500/40 font-semibold">
              Primary System
            </span>
          </div>
          <p className="text-xs text-slate-200 font-medium leading-relaxed">
            {product2.specs.camera || "Advanced Multilens Array"}
          </p>
        </div>
      </div>

      {/* Scenario Selector Pills */}
      <div>
        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2.5">
          Select Photo Shootout Test:
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {scenarios.map((sc) => {
            const Icon = scenarioIcons[sc.id] || Camera;
            const isSelected = selectedScenarioId === sc.id;
            return (
              <button
                key={sc.id}
                onClick={() => setSelectedScenarioId(sc.id)}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? "bg-purple-600 text-white border-purple-400 shadow-[0_0_20px_rgba(168,85,247,0.4)] ring-1 ring-purple-300"
                    : "bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-850 hover:border-slate-700"
                }`}
              >
                <div className="flex items-center justify-between w-full mb-2">
                  <Icon className={`w-4 h-4 ${isSelected ? "text-white" : "text-purple-400"}`} />
                  {sc.winner !== "tie" && (
                    <span
                      className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                        isSelected
                          ? "bg-white/20 text-white"
                          : sc.winner === "product1"
                          ? "bg-emerald-950 text-emerald-300 border border-emerald-500/30"
                          : "bg-amber-950 text-amber-300 border border-amber-500/30"
                      }`}
                    >
                      {sc.winner === "product1" ? "Unit A Leads" : "Unit B Leads"}
                    </span>
                  )}
                </div>
                <span className="text-xs font-bold leading-tight">{sc.title}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Scenario Detail Benchmarking */}
      {activeScenario && (
        <div className="bg-slate-900/80 rounded-xl border border-slate-800 p-4 sm:p-5 space-y-4 shadow-inner">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-purple-950 text-purple-300 border border-purple-500/40 uppercase tracking-wider font-mono">
                {activeScenario.badge}
              </span>
              <h4 className="text-sm sm:text-base font-extrabold text-white mt-1">
                {activeScenario.title}
              </h4>
            </div>

            <div className="flex items-center space-x-2">
              <Trophy className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold text-slate-300">
                Scenario Winner:{" "}
                <span
                  className={
                    activeScenario.winner === "product1"
                      ? "text-emerald-400"
                      : activeScenario.winner === "product2"
                      ? "text-amber-400"
                      : "text-slate-400"
                  }
                >
                  {activeScenario.winner === "product1"
                    ? product1.name
                    : activeScenario.winner === "product2"
                    ? product2.name
                    : "Dead Heat Tie"}
                </span>
              </span>
            </div>
          </div>

          {/* AI Optical Analysis Description */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 text-xs sm:text-sm text-slate-300 leading-relaxed">
            <p>{activeScenario.analysis}</p>
          </div>

          {/* Head to Head Strengths in this Scenario */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3.5 bg-slate-950/80 rounded-xl border border-slate-800">
              <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider block mb-1">
                {product1.name} In This Scene
              </span>
              <p className="text-xs text-slate-300 leading-relaxed">
                {activeScenario.p1Strengths}
              </p>
              <div className="mt-2 text-[11px] font-mono text-slate-400 bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800">
                Config: {activeScenario.p1Metric}
              </div>
            </div>

            <div className="p-3.5 bg-slate-950/80 rounded-xl border border-slate-800">
              <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider block mb-1">
                {product2.name} In This Scene
              </span>
              <p className="text-xs text-slate-300 leading-relaxed">
                {activeScenario.p2Strengths}
              </p>
              <div className="mt-2 text-[11px] font-mono text-slate-400 bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800">
                Config: {activeScenario.p2Metric}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
