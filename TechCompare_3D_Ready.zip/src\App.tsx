import { useState, useEffect, useRef } from "react";
import { Navbar } from "./components/Navbar";
import { ComparisonInput } from "./components/ComparisonInput";
import { ProductProfileCard } from "./components/ProductProfileCard";
import { RadarChartComparison } from "./components/RadarChartComparison";
import { PerformanceBarChart } from "./components/PerformanceBarChart";
import { FeatureHeadToHead } from "./components/FeatureHeadToHead";
import { ResearchReportCard } from "./components/ResearchReportCard";
import { HistoryModal } from "./components/HistoryModal";
import { AndroidPhoneFrame } from "./components/AndroidPhoneFrame";
import { AICopilotChat } from "./components/AICopilotChat";
import { AICameraLab } from "./components/AICameraLab";
import { AIPersonaMatch } from "./components/AIPersonaMatch";
import { AndroidInstallModal } from "./components/AndroidInstallModal";
import { AIAuthenticatorVerdictCard } from "./components/AIAuthenticatorVerdictCard";
import { Insane3DLoading } from "./components/Insane3DLoading";
import { ComparisonData, ComparisonHistoryItem, AndroidTab } from "./types";
import {
  Sparkles,
  AlertTriangle,
  Copy,
  Check,
  Trophy,
  Layers,
  Smartphone,
  Camera,
  Target,
  Bot,
  FileText,
  Sliders,
  Box,
  LayoutGrid,
  Zap,
} from "lucide-react";

export default function App() {
  const [product1, setProduct1] = useState("iPhone 16 Pro Max");
  const [product2, setProduct2] = useState("Samsung Galaxy S25 Ultra");
  const [region, setRegion] = useState("India (INR, ₹)");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [comparisonData, setComparisonData] = useState<ComparisonData | null>(null);
  const [history, setHistory] = useState<ComparisonHistoryItem[]>([]);
  const [historyModalOpen, setHistoryModalOpen] = useState(false);
  const [installModalOpen, setInstallModalOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  // Android Mode & Tab States
  const [isAndroidMode, setIsAndroidMode] = useState(false);
  const [activeTab, setActiveTab] = useState<AndroidTab>("overview");
  const [desktopViewMode, setDesktopViewMode] = useState<"all" | AndroidTab>("all");
  const [scrollProgress, setScrollProgress] = useState(0);

  const resultsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      const scrolled = document.documentElement.scrollTop;
      const max = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      setScrollProgress(max > 0 ? (scrolled / max) * 100 : 0);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Load history & auto-detect screen size
  useEffect(() => {
    try {
      const saved = localStorage.getItem("techcompare_history");
      if (saved) {
        setHistory(JSON.parse(saved));
      }
    } catch {
      // ignore
    }
  }, []);

  const saveToHistory = (data: ComparisonData) => {
    const newItem: ComparisonHistoryItem = {
      id: Date.now().toString(),
      product1Name: data.product1.name,
      product2Name: data.product2.name,
      region,
      timestamp: Date.now(),
      data,
    };
    const updated = [
      newItem,
      ...history.filter(
        (h) => h.product1Name !== data.product1.name || h.product2Name !== data.product2.name
      ),
    ].slice(0, 10);
    setHistory(updated);
    try {
      localStorage.setItem("techcompare_history", JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  const handleClearHistory = () => {
    setHistory([]);
    try {
      localStorage.removeItem("techcompare_history");
    } catch {
      // ignore
    }
  };

  const [loadingStep, setLoadingStep] = useState(0);

  const handleCompare = async () => {
    if (!product1.trim() || !product2.trim()) {
      setError("Please enter both products to compare.");
      return;
    }

    setLoading(true);
    setError(null);
    setLoadingStep(0);

    const stepInterval = setInterval(() => {
      setLoadingStep((prev) => (prev < 3 ? prev + 1 : prev));
    }, 900);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => {
      try {
        controller.abort(new DOMException("Comparison request timed out", "TimeoutError"));
      } catch {
        controller.abort();
      }
    }, 75000);

    try {
      const res = await fetch("/api/compare", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          product1: product1.trim(),
          product2: product2.trim(),
          region,
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);
      clearInterval(stepInterval);

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || `Server responded with status ${res.status}`);
      }

      const data: ComparisonData = await res.json();
      setComparisonData(data);
      saveToHistory(data);

      setTimeout(() => {
        resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 100);
    } catch (err: any) {
      clearInterval(stepInterval);
      clearTimeout(timeoutId);
      console.error(err);
      if (
        err.name === "AbortError" ||
        err.name === "TimeoutError" ||
        (typeof err.message === "string" && err.message.toLowerCase().includes("abort"))
      ) {
        setError("Comparison request took longer than expected. Please try again.");
      } else {
        setError(err.message || "Failed to fetch hardware comparison. Please try again.");
      }
    } finally {
      clearInterval(stepInterval);
      setLoading(false);
    }
  };

  const handleReset = () => {
    setComparisonData(null);
    setError(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSelectHistory = (item: ComparisonHistoryItem) => {
    setProduct1(item.product1Name);
    setProduct2(item.product2Name);
    setRegion(item.region);
    setComparisonData(item.data);
    setTimeout(() => {
      resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 100);
  };

  const handleCopySummary = () => {
    if (!comparisonData) return;
    const text =
      `🏆 TechCompare AI 3D Silicon Dossier: ${comparisonData.product1.name} vs ${comparisonData.product2.name}\n\n` +
      `💡 AI Verdict: ${comparisonData.summary}\n\n` +
      `🎯 Recommendation: ${comparisonData.winnerRecommendation}\n\n` +
      `💰 Pricing (${region}):\n- ${comparisonData.product1.name}: ${comparisonData.product1.price}\n- ${comparisonData.product2.name}: ${comparisonData.product2.price}`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const p1Score = comparisonData?.product1.radarScores.Overall || 0;
  const p2Score = comparisonData?.product2.radarScores.Overall || 0;
  
  // Strict zero-bias winner resolution derived from Gemini 3.7 / 3.1 dual-stage pipeline
  const isP1Winner = comparisonData?.overallWinner
    ? comparisonData.overallWinner === "product1"
    : p1Score > p2Score;
  const isP2Winner = comparisonData?.overallWinner
    ? comparisonData.overallWinner === "product2"
    : p2Score > p1Score;
  const winnerName = isP1Winner
    ? comparisonData?.product1.name
    : isP2Winner
    ? comparisonData?.product2.name
    : "Both Devices";

  // Desktop Navigation Items
  const desktopNavItems = [
    { id: "all", label: "Complete Deck", icon: LayoutGrid },
    { id: "overview", label: "Core Battle", icon: Layers },
    { id: "specs", label: "Specs Matrix", icon: Sliders },
    { id: "report", label: "Intelligence Dossier", icon: FileText },
    { id: "copilot", label: "AI Copilot", icon: Bot, badge: "3.7" },
    { id: "camera", label: "Camera Lab", icon: Camera },
    { id: "persona", label: "Workload Fit", icon: Target },
  ];

  return (
    <div className="min-h-screen text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950 cyber-grid relative overflow-x-hidden">
      {/* Scroll Progress Bar */}
      <div className="fixed top-0 left-0 w-full h-1 z-[100] bg-slate-900">
        <div 
          className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 shadow-[0_0_10px_rgba(34,211,238,0.8)] transition-all duration-150 ease-out"
          style={{ width: `${scrollProgress}%` }}
        />
      </div>

      {/* Background ambient glows */}
      <div className="fixed top-0 left-1/4 w-96 h-96 bg-cyan-950 rounded-full blur-3xl pointer-events-none opacity-50" />
      <div className="fixed bottom-0 right-1/4 w-96 h-96 bg-amber-950 rounded-full blur-3xl pointer-events-none opacity-50" />

      <Navbar
        onReset={handleReset}
        hasResults={Boolean(comparisonData)}
        historyCount={history.length}
        onOpenHistory={() => setHistoryModalOpen(true)}
        isAndroidMode={isAndroidMode}
        onToggleAndroidMode={() => setIsAndroidMode((prev) => !prev)}
        onOpenInstall={() => setInstallModalOpen(true)}
      />

      <main className="flex-grow max-w-6xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-6 sm:py-10 space-y-6 relative z-10">
        {/* Search & Input Block */}
        <ComparisonInput
          product1={product1}
          setProduct1={setProduct1}
          product2={product2}
          setProduct2={setProduct2}
          region={region}
          setRegion={setRegion}
          onCompare={handleCompare}
          loading={loading}
        />

        {/* Loading Indicator */}
        {loading && (
          <Insane3DLoading 
            loadingStep={loadingStep} 
            product1={product1} 
            product2={product2} 
          />
        )}

        {/* Error Banner */}
        {error && (
          <div className="bg-rose-950/40 border border-rose-800/80 text-rose-200 p-4 rounded-xl flex items-start space-x-3 shadow-lg">
            <AlertTriangle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
            <div className="flex-grow">
              <h4 className="font-bold text-sm text-rose-300">Comparison Notice</h4>
              <p className="text-xs text-rose-400 mt-0.5">{error}</p>
            </div>
            <button
              onClick={() => setError(null)}
              className="text-xs text-rose-300 hover:text-white px-2.5 py-1 bg-rose-900/60 border border-rose-700/80 rounded-lg cursor-pointer transition-colors"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Comparison Results in Android Phone Frame OR Desktop 3D View */}
        {comparisonData && !loading && (
          <div ref={resultsRef} className="w-full space-y-6">
            {/* Mode Switcher Bar */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 bg-slate-900/70 backdrop-blur-md rounded-2xl border border-slate-800/90 shadow-sm">
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
                  <Box className="w-4 h-4 text-cyan-400" />
                  <span>3D Layout Engine:</span>
                </span>
                <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-500/40 font-mono">
                  {isAndroidMode ? "Android 3D Cyber Shell" : "Desktop Panoramic 3D Deck"}
                </span>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setIsAndroidMode((prev) => !prev)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 cursor-pointer ${
                    isAndroidMode
                      ? "bg-cyan-500 text-slate-950 shadow-[0_0_15px_rgba(6,182,212,0.4)]"
                      : "bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700"
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>{isAndroidMode ? "Switch to Desktop 3D" : "Switch to Android Shell"}</span>
                </button>
              </div>
            </div>

            {/* Desktop Navigation Selector (When in Desktop Mode) */}
            {!isAndroidMode && (
              <div className="flex items-center space-x-1.5 overflow-x-auto pb-2 scrollbar-none">
                {desktopNavItems.map((item) => {
                  const Icon = item.icon;
                  const isSelected = desktopViewMode === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setDesktopViewMode(item.id as any)}
                      className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer border ${
                        isSelected
                          ? "bg-gradient-to-r from-cyan-500 to-blue-600 text-white border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.4)]"
                          : "bg-slate-900/80 text-slate-300 border-slate-800 hover:bg-slate-800 hover:text-white hover:border-slate-700"
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5 shrink-0" />
                      <span>{item.label}</span>
                      {item.badge && (
                        <span className="px-1.5 py-0.2 rounded-full bg-cyan-400 text-slate-950 text-[9px] font-extrabold">
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            )}

            {/* If Android Mode is ON */}
            {isAndroidMode ? (
              <AndroidPhoneFrame
                activeTab={activeTab}
                setActiveTab={setActiveTab}
                hasResults={Boolean(comparisonData)}
                onReset={handleReset}
                product1Name={comparisonData.product1.name}
                product2Name={comparisonData.product2.name}
              >
                {/* TAB 1: Overview */}
                {activeTab === "overview" && (
                  <div className="space-y-4">
                    {/* AI Top Picker & Authenticator Card */}
                    <AIAuthenticatorVerdictCard
                      verdict={comparisonData.authenticatorVerdict}
                      overallWinner={comparisonData.overallWinner}
                      product1={comparisonData.product1}
                      product2={comparisonData.product2}
                      winnerRecommendation={comparisonData.winnerRecommendation}
                    />

                    {/* AI Verdict Card */}
                    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-sm">
                      <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                        <div className="flex items-center space-x-2">
                          <div className="w-7 h-7 rounded-lg bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
                            <Sparkles className="w-3.5 h-3.5" />
                          </div>
                          <h3 className="text-sm font-extrabold text-white">AI Verdict</h3>
                        </div>
                        <button
                          onClick={handleCopySummary}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-200 text-[11px] font-semibold flex items-center space-x-1"
                        >
                          {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-cyan-400" />}
                          <span>{copied ? "Copied" : "Copy"}</span>
                        </button>
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed mb-3">
                        {comparisonData.summary}
                      </p>
                      {comparisonData.winnerRecommendation && (
                        <div className="p-2.5 rounded-xl bg-cyan-950/40 border border-cyan-500/30 flex items-start space-x-2">
                          <Trophy className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                          <p className="text-xs text-cyan-200 font-medium">
                            {comparisonData.winnerRecommendation}
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Product Cards */}
                    <ProductProfileCard
                      product={comparisonData.product1}
                      isWinner={isP1Winner}
                      themeColor="emerald"
                    />
                    <ProductProfileCard
                      product={comparisonData.product2}
                      isWinner={isP2Winner}
                      themeColor="amber"
                    />

                    {/* Charts */}
                    <RadarChartComparison
                      product1={comparisonData.product1}
                      product2={comparisonData.product2}
                    />
                    <PerformanceBarChart
                      product1={comparisonData.product1}
                      product2={comparisonData.product2}
                    />
                  </div>
                )}

                {/* TAB 2: Specs Matrix */}
                {activeTab === "specs" && (
                  <FeatureHeadToHead
                    product1={comparisonData.product1}
                    product2={comparisonData.product2}
                    specWinners={comparisonData.specWinners}
                    verdict={{
                      winner: winnerName,
                      summary: comparisonData.summary,
                      product1Wins: comparisonData.product1.highlights,
                      product2Wins: comparisonData.product2.highlights,
                    }}
                  />
                )}

                {/* TAB 3: Dossier */}
                {activeTab === "report" && (
                  <ResearchReportCard comparisonData={comparisonData} />
                )}

                {/* TAB 4: Copilot */}
                {activeTab === "copilot" && (
                  <AICopilotChat
                    product1={comparisonData.product1}
                    product2={comparisonData.product2}
                  />
                )}

                {/* TAB 5: Camera */}
                {activeTab === "camera" && (
                  <AICameraLab
                    product1={comparisonData.product1}
                    product2={comparisonData.product2}
                  />
                )}

                {/* TAB 6: Persona */}
                {activeTab === "persona" && (
                  <AIPersonaMatch
                    product1={comparisonData.product1}
                    product2={comparisonData.product2}
                  />
                )}
              </AndroidPhoneFrame>
            ) : (
              /* Desktop Mode (Full Width Panoramic 3D View) */
              <div className="space-y-8">
                {/* AI Authenticator Top Picker Verdict Card */}
                {(desktopViewMode === "all" || desktopViewMode === "overview") && (
                  <AIAuthenticatorVerdictCard
                    verdict={comparisonData.authenticatorVerdict}
                    overallWinner={comparisonData.overallWinner}
                    product1={comparisonData.product1}
                    product2={comparisonData.product2}
                    winnerRecommendation={comparisonData.winnerRecommendation}
                  />
                )}

                {/* AI Verdict Card */}
                {(desktopViewMode === "all" || desktopViewMode === "overview") && (
                  <div className="relative bg-[#0d121f]/90 backdrop-blur-2xl border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-[0_20px_40px_rgba(0,0,0,0.8),inset_0_1px_0_0_rgba(255,255,255,0.08)]">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4 pb-4 border-b border-slate-800">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-xl bg-cyan-950/80 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.3)]">
                          <Sparkles className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="text-lg font-extrabold text-white">
                            Synthesized AI Verdict & Architectural Verdict
                          </h3>
                          <span className="text-xs text-slate-400">
                            Deep Gemini 3.7 Flash Hardware Analysis & 3.1 Verification
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <button
                          onClick={handleCopySummary}
                          className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-semibold flex items-center space-x-1.5 transition-all border border-slate-700 shadow-sm cursor-pointer"
                        >
                          {copied ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                              <span className="text-emerald-400">Copied to Clipboard!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5 text-cyan-400" />
                              <span>Copy Verdict</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>

                    <p className="text-slate-300 text-xs sm:text-sm leading-relaxed mb-4">
                      {comparisonData.summary}
                    </p>

                    {comparisonData.winnerRecommendation && (
                      <div className="p-4 rounded-xl bg-cyan-950/30 border border-cyan-500/30 flex items-start space-x-3 shadow-inner">
                        <Trophy className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                        <div>
                          <span className="text-[10px] font-extrabold uppercase tracking-widest text-cyan-300 block mb-0.5">
                            AI Buying Recommendation
                          </span>
                          <p className="text-xs sm:text-sm text-white font-semibold leading-relaxed">
                            {comparisonData.winnerRecommendation}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Profiles & Radar/Bar Charts */}
                {(desktopViewMode === "all" || desktopViewMode === "overview") && (
                  <>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <ProductProfileCard
                        product={comparisonData.product1}
                        isWinner={isP1Winner}
                        themeColor="emerald"
                      />
                      <ProductProfileCard
                        product={comparisonData.product2}
                        isWinner={isP2Winner}
                        themeColor="amber"
                      />
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      <RadarChartComparison
                        product1={comparisonData.product1}
                        product2={comparisonData.product2}
                      />
                      <PerformanceBarChart
                        product1={comparisonData.product1}
                        product2={comparisonData.product2}
                      />
                    </div>
                  </>
                )}

                {/* Specs Matrix */}
                {(desktopViewMode === "all" || desktopViewMode === "specs") && (
                  <FeatureHeadToHead
                    product1={comparisonData.product1}
                    product2={comparisonData.product2}
                    specWinners={comparisonData.specWinners}
                    verdict={{
                      winner: winnerName,
                      summary: comparisonData.summary,
                      product1Wins: comparisonData.product1.highlights,
                      product2Wins: comparisonData.product2.highlights,
                    }}
                  />
                )}

                {/* Dossier Report */}
                {(desktopViewMode === "all" || desktopViewMode === "report") && (
                  <ResearchReportCard comparisonData={comparisonData} />
                )}

                {/* AI Copilot Chat */}
                {(desktopViewMode === "all" || desktopViewMode === "copilot") && (
                  <AICopilotChat
                    product1={comparisonData.product1}
                    product2={comparisonData.product2}
                  />
                )}

                {/* Camera Lab & Persona Matcher */}
                {(desktopViewMode === "all" || desktopViewMode === "camera") && (
                  <AICameraLab
                    product1={comparisonData.product1}
                    product2={comparisonData.product2}
                  />
                )}

                {(desktopViewMode === "all" || desktopViewMode === "persona") && (
                  <AIPersonaMatch
                    product1={comparisonData.product1}
                    product2={comparisonData.product2}
                  />
                )}
              </div>
            )}
          </div>
        )}
      </main>

      {/* History Modal */}
      <HistoryModal
        isOpen={historyModalOpen}
        onClose={() => setHistoryModalOpen(false)}
        history={history}
        onSelect={handleSelectHistory}
        onClear={handleClearHistory}
      />

      {/* Android Install PWA Modal */}
      <AndroidInstallModal
        isOpen={installModalOpen}
        onClose={() => setInstallModalOpen(false)}
      />

      {/* Dark Footer */}
      <footer className="border-t border-slate-800/80 bg-[#090d16]/90 backdrop-blur-md py-6 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            <span className="font-semibold text-slate-300">
              TechCompare AI 3D Edition
            </span>
          </div>
          <p className="text-slate-400">
            Powered by Gemini 3.7 Flash & 3.1 Authenticator • 3D Silicon & Benchmark Engine
          </p>
        </div>
      </footer>
    </div>
  );
}
