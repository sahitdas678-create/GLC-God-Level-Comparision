import React, { useRef, useMemo, useState, useEffect } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Text, Float, Stars, OrbitControls, Sphere, MeshDistortMaterial } from "@react-three/drei";
import * as THREE from "three";

const TAGS = [
  "BENCHMARKING",
  "NEURAL ENGINE",
  "L3 CACHE",
  "GPU COMPUTE",
  "THERMAL THROTTLING",
  "SILICON ARCHITECTURE",
  "CLOCK SPEEDS",
  "TDP OPTIMIZATION",
  "RAY TRACING",
  "MEMORY BANDWIDTH",
];

const DATA_STREAMS = Array.from({ length: 50 }).map(() => ({
  x: (Math.random() - 0.5) * 15,
  y: (Math.random() - 0.5) * 15,
  z: (Math.random() - 0.5) * 15,
  speed: Math.random() * 0.05 + 0.01,
  text: Math.random() > 0.5 ? (Math.random() * 10000).toFixed(2) : "0x" + Math.floor(Math.random() * 16777215).toString(16).toUpperCase(),
}));

function FloatingTags() {
  const group = useRef<THREE.Group>(null);
  
  useFrame(({ clock }) => {
    if (group.current) {
      group.current.rotation.y = clock.getElapsedTime() * 0.1;
      group.current.rotation.z = Math.sin(clock.getElapsedTime() * 0.05) * 0.2;
    }
  });

  return (
    <group ref={group}>
      {TAGS.map((tag, i) => {
        const angle = (i / TAGS.length) * Math.PI * 2;
        const radius = 6 + Math.sin(i * 1.5) * 2;
        const x = Math.cos(angle) * radius;
        const z = Math.sin(angle) * radius;
        const y = (Math.random() - 0.5) * 6;
        return (
          <Float key={i} speed={2} rotationIntensity={1} floatIntensity={2}>
            <Text
              position={[x, y, z]}
              fontSize={0.4}
              color="#22d3ee" // cyan-400
              anchorX="center"
              anchorY="middle"
              outlineWidth={0.02}
              outlineColor="#0f172a"
            >
              {tag}
            </Text>
          </Float>
        );
      })}
    </group>
  );
}

function ProcessingCore() {
  const meshRef = useRef<THREE.Mesh>(null);
  
  useFrame(({ clock }) => {
    if (meshRef.current) {
      meshRef.current.rotation.x = clock.getElapsedTime() * 0.2;
      meshRef.current.rotation.y = clock.getElapsedTime() * 0.3;
    }
  });

  return (
    <Float speed={4} rotationIntensity={1} floatIntensity={1}>
      <Sphere ref={meshRef} args={[2, 64, 64]} scale={1.2}>
        <MeshDistortMaterial
          color="#0891b2"
          envMapIntensity={1}
          clearcoat={1}
          clearcoatRoughness={0.1}
          metalness={0.8}
          roughness={0.2}
          distort={0.4}
          speed={3}
          wireframe={true}
        />
      </Sphere>
      <Sphere args={[1.8, 32, 32]}>
        <meshStandardMaterial color="#020617" emissive="#06b6d4" emissiveIntensity={2} wireframe />
      </Sphere>
    </Float>
  );
}

function DataStreamMatrix() {
  const group = useRef<THREE.Group>(null);
  const streamData = useMemo(() => DATA_STREAMS, []);

  useFrame(() => {
    if (group.current) {
      group.current.children.forEach((child, i) => {
        child.position.y += streamData[i].speed;
        if (child.position.y > 10) {
          child.position.y = -10;
        }
      });
    }
  });

  return (
    <group ref={group}>
      {streamData.map((data, i) => (
        <Text
          key={i}
          position={[data.x, data.y, data.z]}
          fontSize={0.2}
          color="#38bdf8"
          fillOpacity={0.6}
        >
          {data.text}
        </Text>
      ))}
    </group>
  );
}

export function Insane3DLoading({ loadingStep, product1, product2 }: { loadingStep: number, product1: string, product2: string }) {
  const steps = [
    `Scanning live specs for ${product1} and ${product2}...`,
    "Benchmarking microarchitecture & cooling curves...",
    "Processing regional pricing & telemetry...",
    "Generating silicon dossier & verification audit...",
  ];

  return (
    <div className="relative w-full h-[600px] bg-[#020617] border border-cyan-900/50 rounded-2xl overflow-hidden shadow-[0_0_50px_rgba(6,182,212,0.15)] flex flex-col">
      <div className="absolute inset-0 z-0">
        <Canvas camera={{ position: [0, 0, 10], fov: 60 }}>
          <ambientLight intensity={0.5} />
          <pointLight position={[10, 10, 10]} intensity={1} color="#06b6d4" />
          <pointLight position={[-10, -10, -10]} intensity={0.5} color="#3b82f6" />
          <Stars radius={50} depth={50} count={2000} factor={4} saturation={0} fade speed={2} />
          
          <ProcessingCore />
          <FloatingTags />
          <DataStreamMatrix />
          
          <OrbitControls enableZoom={false} autoRotate autoRotateSpeed={1} maxPolarAngle={Math.PI / 2 + 0.2} minPolarAngle={Math.PI / 2 - 0.2} />
        </Canvas>
      </div>

      <div className="absolute inset-0 z-10 pointer-events-none flex flex-col justify-end p-8 bg-gradient-to-t from-[#020617] via-transparent to-transparent">
        <div className="max-w-2xl mx-auto w-full backdrop-blur-md bg-slate-950/60 border border-cyan-500/30 p-6 rounded-2xl shadow-2xl">
          <div className="flex items-center space-x-4 mb-4">
            <div className="relative w-10 h-10 flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border-2 border-slate-700" />
              <div className="absolute inset-0 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin" />
            </div>
            <div>
              <h3 className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-blue-500 uppercase tracking-widest">
                System Processing
              </h3>
              <p className="text-cyan-200/80 font-mono text-sm h-5 overflow-hidden">
                <span className="inline-block animate-pulse">_</span> {steps[loadingStep] || steps[3]}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-1.5 w-full mt-4">
            {[0, 1, 2, 3].map((step) => (
              <div
                key={step}
                className={`h-1.5 rounded-full transition-all duration-500 ${
                  loadingStep >= step
                    ? "w-full bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.8)]"
                    : "w-full bg-slate-800"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
      
      {/* Overlay Matrix Text */}
      <div className="absolute top-4 left-4 right-4 z-10 flex justify-between pointer-events-none opacity-50">
        <div className="font-mono text-[10px] text-cyan-400 flex flex-col gap-1">
          <span>SYS.LATENCY: {(Math.random() * 10).toFixed(2)}ms</span>
          <span>NET.THROUGHPUT: {(Math.random() * 100 + 900).toFixed(0)} GB/s</span>
          <span>MEM.ALLOC: 0x{(Math.random() * 10000000).toString(16)}</span>
        </div>
        <div className="font-mono text-[10px] text-cyan-400 text-right flex flex-col gap-1">
          <span>AI.NODE: ACTIVE</span>
          <span>THREAD.POOL: {Math.floor(Math.random() * 128)}/128</span>
          <span>NEURAL.OPS: {(Math.random() * 100).toFixed(1)} TFLOPS</span>
        </div>
      </div>
    </div>
  );
}
