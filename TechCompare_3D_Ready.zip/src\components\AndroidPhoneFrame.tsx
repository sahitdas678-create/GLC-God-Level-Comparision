import React, { useState, useEffect } from "react";
import {
  Wifi,
  Battery,
  Signal,
  RotateCcw,
  Sparkles,
  Smartphone,
  Bot,
  Camera,
  Target,
  FileText,
  Home,
  Sliders,
} from "lucide-react";
import { AndroidTab } from "../types";

interface AndroidPhoneFrameProps {
  children: React.ReactNode;
  activeTab: AndroidTab;
  setActiveTab: (tab: AndroidTab) => void;
  hasResults: boolean;
  onReset: () => void;
  product1Name?: string;
  product2Name?: string;
}

export function AndroidPhoneFrame({
  children,
  activeTab,
  setActiveTab,
  hasResults,
  onReset,
  product1Name,
  product2Name,
}: AndroidPhoneFrameProps) {
  const [currentTime, setCurrentTime] = useState("");

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false })
      );
    };
    updateTime();
    const timer = setInterval(updateTime, 30000);
    return () => clearInterval(timer);
  }, []);

  const navItems: { id: AndroidTab; label: string; icon: any; badge?: string }[] = [
    { id: "overview", label: "Overview", icon: Home },
    { id: "specs", label: "Specs", icon: Sliders },
    { id: "report", label: "Dossier", icon: FileText },
    { id: "copilot", label: "Copilot", icon: Bot, badge: "3.7" },
    { id: "camera", label: "Camera", icon: Camera },
    { id: "persona", label: "Persona", icon: Target },
  ];

  const handleTabClick = (tabId: AndroidTab) => {
    if (typeof navigator !== "undefined" && navigator.vibrate) {
      try {
        navigator.vibrate(12);
      } catch {
        // ignore
      }
    }
    setActiveTab(tabId);
  };

  return (
    <div className="flex justify-center items-center py-4 px-2 sm:px-4">
      {/* Clean Android Device Frame */}
      <div className="relative w-full max-w-[440px] rounded-[48px] bg-slate-900 p-[10px] shadow-2xl border border-slate-800 transition-transform duration-500">
        
        {/* Antenna bands / physical styling accents */}
        <div className="absolute top-24 -left-[2px] w-[3px] h-10 bg-slate-800 rounded-l-xs" />
        <div className="absolute top-40 -left-[2px] w-[3px] h-14 bg-slate-800 rounded-l-xs" />
        <div className="absolute top-28 -right-[2px] w-[3px] h-12 bg-slate-800 rounded-r-xs" />

        {/* AMOLED Screen Bezel */}
        <div className="relative bg-slate-950 rounded-[40px] overflow-hidden flex flex-col h-[820px] max-h-[88vh] border border-slate-900 shadow-inner">
          
          {/* Android 15 Status Bar */}
          <div className="bg-slate-950/95 backdrop-blur-md px-6 pt-3 pb-2 flex items-center justify-between text-slate-300 text-[11px] font-semibold tracking-wider select-none shrink-0 z-20 border-b border-slate-900">
            {/* Clock & Notifications */}
            <div className="flex items-center space-x-1.5">
              <span>{currentTime || "12:00"}</span>
              <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse ml-1" />
            </div>

            {/* Centered Camera Hole Punch */}
            <div className="w-4 h-4 rounded-full bg-black border border-slate-800 flex items-center justify-center shadow-inner">
              <div className="w-1.5 h-1.5 rounded-full bg-slate-900" />
            </div>

            {/* Status Icons */}
            <div className="flex items-center space-x-2 text-slate-300">
              <span className="text-[9px] font-mono text-cyan-400 font-bold">5G</span>
              <Signal className="w-3 h-3 text-slate-300" />
              <Wifi className="w-3 h-3 text-slate-300" />
              <div className="flex items-center space-x-0.5">
                <Battery className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-[10px] text-emerald-400 font-bold">98%</span>
              </div>
            </div>
          </div>

          {/* Android App Bar */}
          <div className="bg-[#090d16]/95 px-4 py-2.5 flex items-center justify-between border-b border-slate-800 shrink-0 z-10">
            <div className="flex items-center space-x-2">
              <div className="w-7 h-7 rounded-lg bg-cyan-950 border border-cyan-500/40 flex items-center justify-center shadow-[0_0_10px_rgba(6,182,212,0.3)]">
                <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
              </div>
              <div>
                <span className="text-xs font-bold text-white tracking-tight block">
                  TechCompare AI
                </span>
                <span className="text-[9px] text-cyan-400 font-mono">
                  Android 15 • 3D Edition
                </span>
              </div>
            </div>

            {hasResults && (
              <button
                onClick={onReset}
                className="p-1.5 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                title="New Matchup"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Scrollable Content Viewport */}
          <div className="flex-1 overflow-y-auto px-3.5 py-4 space-y-4 scrollbar-thin bg-gradient-to-b from-[#07090e] to-[#0a0f1d]">
            {children}
          </div>

          {/* Material Design 3 (M3) Bottom Navigation Bar */}
          {hasResults && (
            <div className="bg-[#090d16]/95 backdrop-blur-xl border-t border-slate-800 px-1.5 py-2 shrink-0 z-20">
              <div className="grid grid-cols-6 gap-0.5">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleTabClick(item.id)}
                      className={`flex flex-col items-center justify-center py-1 px-0.5 rounded-xl transition-all cursor-pointer relative ${
                        isActive
                          ? "text-cyan-400 font-bold"
                          : "text-slate-400 hover:text-slate-200"
                      }`}
                    >
                      {/* Active M3 Indicator Bubble */}
                      <div
                        className={`w-9 h-6 rounded-full flex items-center justify-center transition-all ${
                          isActive
                            ? "bg-cyan-950/80 border border-cyan-500/40 shadow-[0_0_12px_rgba(6,182,212,0.3)] text-cyan-300"
                            : "bg-transparent text-slate-400"
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5" />
                      </div>
                      <span className="text-[9px] mt-1 tracking-tight truncate max-w-full">
                        {item.label}
                      </span>
                      {item.badge && (
                        <span className="absolute top-0 right-0 px-1 rounded-full bg-cyan-400 text-slate-950 text-[7px] font-extrabold">
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Android Gesture Navigation Bar */}
          <div className="bg-[#090d16] py-2 flex justify-center items-center shrink-0 border-t border-slate-900 select-none">
            <div className="w-32 h-1 bg-slate-600 rounded-full hover:bg-cyan-400 transition-colors cursor-pointer" />
          </div>
        </div>
      </div>
    </div>
  );
}
