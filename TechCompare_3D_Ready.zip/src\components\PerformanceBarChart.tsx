import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { ProductDetails } from "../types";
import { BarChart3 } from "lucide-react";

interface PerformanceBarChartProps {
  product1: ProductDetails;
  product2: ProductDetails;
}

export function PerformanceBarChart({ product1, product2 }: PerformanceBarChartProps) {
  const metrics = [
    { key: "Processing", label: "CPU Compute" },
    { key: "Graphics", label: "GPU Raster" },
    { key: "Memory", label: "Memory" },
    { key: "Display", label: "Display" },
    { key: "Battery", label: "Battery" },
    { key: "Camera", label: "Camera" },
    { key: "Portability", label: "Portability" },
    { key: "Value", label: "Value" },
  ];

  const chartData = metrics.map((m) => ({
    name: m.label,
    [product1.name]: product1.radarScores[m.key as keyof typeof product1.radarScores] || 0,
    [product2.name]: product2.radarScores[m.key as keyof typeof product2.radarScores] || 0,
  }));

  return (
    <div className="relative bg-[#0d121f]/90 backdrop-blur-2xl border border-slate-800/90 rounded-2xl p-6 shadow-[0_20px_40px_rgba(0,0,0,0.8),inset_0_1px_0_0_rgba(255,255,255,0.08)] flex flex-col h-[490px] transition-all hover:border-slate-700">
      {/* Header */}
      <div className="text-left mb-3 pb-3 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <div className="flex items-center space-x-2">
            <BarChart3 className="w-4 h-4 text-cyan-400" />
            <h3 className="text-base font-extrabold text-white">Direct Benchmark Scores</h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Normalized 0–10 compute, thermal, and raster performance metrics
          </p>
        </div>

        {/* Legend */}
        <div className="flex items-center space-x-2">
          <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs font-bold shadow-[0_0_10px_rgba(16,185,129,0.2)]">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
            <span className="truncate max-w-[120px]">{product1.name}</span>
          </span>
          <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-amber-950/60 border border-amber-500/40 text-amber-300 text-xs font-bold shadow-[0_0_10px_rgba(245,158,11,0.2)]">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
            <span className="truncate max-w-[120px]">{product2.name}</span>
          </span>
        </div>
      </div>

      <div className="flex-grow w-full h-full relative min-h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={chartData}
            margin={{ top: 20, right: 20, left: -10, bottom: 20 }}
            barCategoryGap="25%"
            barGap={4}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
            <XAxis
              dataKey="name"
              stroke="#64748b"
              interval={0}
              tick={{ fill: "#94a3b8", fontSize: 10, fontWeight: 700 }}
              axisLine={{ stroke: "#334155" }}
            />
            <YAxis
              domain={[0, 10]}
              ticks={[0, 2, 4, 6, 8, 10]}
              stroke="#64748b"
              tick={{ fill: "#64748b", fontSize: 11 }}
              axisLine={{ stroke: "#334155" }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "#0f172a",
                borderColor: "#334155",
                borderRadius: "0.75rem",
                color: "#f8fafc",
                fontSize: "12px",
                boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.8)",
              }}
              cursor={{ fill: "rgba(255, 255, 255, 0.03)" }}
            />
            <Legend
              verticalAlign="bottom"
              wrapperStyle={{ paddingTop: "12px", fontSize: "12px", color: "#cbd5e1" }}
            />
            <Bar
              dataKey={product1.name}
              fill="#10b981"
              radius={[6, 6, 0, 0]}
              maxBarSize={36}
            />
            <Bar
              dataKey={product2.name}
              fill="#f59e0b"
              radius={[6, 6, 0, 0]}
              maxBarSize={36}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
