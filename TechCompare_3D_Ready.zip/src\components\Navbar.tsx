import { History, RotateCcw, Cpu, Sparkles, Smartphone, Box, Layers, Zap } from "lucide-react";

interface NavbarProps {
  onReset: () => void;
  hasResults: boolean;
  historyCount: number;
  onOpenHistory: () => void;
  isAndroidMode?: boolean;
  onToggleAndroidMode?: () => void;
  onOpenInstall?: () => void;
}

export function Navbar({
  onReset,
  hasResults,
  historyCount,
  onOpenHistory,
  isAndroidMode = false,
  onToggleAndroidMode,
  onOpenInstall,
}: NavbarProps) {
  return (
    <header className="w-full bg-[#090d16]/90 backdrop-blur-xl border-b border-slate-800/80 sticky top-0 z-50 shadow-[0_10px_30px_rgba(0,0,0,0.8)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand Logo with 3D Holographic Chip Icon */}
        <div 
          onClick={onReset}
          className="flex items-center space-x-3 cursor-pointer group select-none"
        >
          <div className="relative">
            {/* Ambient neon halo */}
            <div className="absolute -inset-1 rounded-xl bg-gradient-to-r from-cyan-500 via-indigo-500 to-purple-500 opacity-70 blur-xs group-hover:opacity-100 transition-all duration-300" />
            <div className="relative w-9 h-9 bg-slate-900 rounded-xl flex items-center justify-center border border-cyan-400/40 shadow-inner group-hover:scale-105 transition-transform">
              <Cpu className="w-4.5 h-4.5 text-cyan-400 group-hover:text-cyan-300 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center space-x-2.5">
              <span className="font-extrabold text-lg tracking-tight text-white drop-shadow-[0_2px_10px_rgba(255,255,255,0.15)]">
                Tech<span className="text-cyan-400">Compare</span>
              </span>
              <span className="px-2 py-0.5 bg-cyan-500/10 text-cyan-300 text-[10px] font-bold uppercase rounded-md tracking-widest border border-cyan-500/30 shadow-[0_0_12px_rgba(6,182,212,0.3)]">
                3D Silicon AI
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium hidden sm:flex items-center space-x-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              <span>Next-Gen Hardware Benchmark & Microarchitecture Engine</span>
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Android App Install Action */}
          {onOpenInstall && (
            <button
              onClick={onOpenInstall}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600/20 to-teal-600/20 hover:from-emerald-600/30 hover:to-teal-600/30 text-emerald-300 text-xs font-semibold flex items-center space-x-1.5 border border-emerald-500/40 shadow-[0_0_15px_rgba(16,185,129,0.2)] hover:border-emerald-400 transition-all cursor-pointer transform hover:-translate-y-0.5"
            >
              <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">Install Android App</span>
              <span className="sm:hidden">Install</span>
            </button>
          )}

          {/* Android Mode Toggle */}
          {onToggleAndroidMode && (
            <button
              onClick={onToggleAndroidMode}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center space-x-1.5 border transition-all cursor-pointer transform hover:-translate-y-0.5 shadow-sm ${
                isAndroidMode
                  ? "bg-cyan-500/20 text-cyan-300 border-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.3)]"
                  : "bg-slate-900/80 text-slate-300 hover:text-white hover:bg-slate-800 border-slate-700/80"
              }`}
            >
              <Box className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">
                {isAndroidMode ? "3D Desktop View" : "Android 3D Shell"}
              </span>
            </button>
          )}

          {historyCount > 0 && (
            <button
              onClick={onOpenHistory}
              className="px-3 py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-700/80 hover:border-slate-600 text-slate-300 hover:text-white text-xs font-semibold flex items-center space-x-1.5 transition-all cursor-pointer transform hover:-translate-y-0.5"
            >
              <History className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">History ({historyCount})</span>
            </button>
          )}

          {hasResults && (
            <button
              onClick={onReset}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold flex items-center space-x-1.5 border border-cyan-400/40 shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all cursor-pointer transform hover:-translate-y-0.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">New Matchup</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
