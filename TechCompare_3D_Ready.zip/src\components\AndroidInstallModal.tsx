import React, { useState, useEffect } from "react";
import { Smartphone, Download, CheckCircle2, X, Sparkles } from "lucide-react";

interface AndroidInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AndroidInstallModal({ isOpen, onClose }: AndroidInstallModalProps) {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstall);
    window.addEventListener("appinstalled", () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    });

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstall);
    };
  }, []);

  const [showManualInstructions, setShowManualInstructions] = useState(false);
  const isIframe = window.self !== window.top;

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === "accepted") {
        setIsInstalled(true);
      }
      setDeferredPrompt(null);
    } else {
      setShowManualInstructions(true);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-[#0d121f] rounded-2xl max-w-md w-full p-6 shadow-[0_25px_60px_rgba(0,0,0,0.9)] border border-slate-800 relative space-y-5">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-[0_0_15px_rgba(6,182,212,0.4)]">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-base font-extrabold text-white">Install Android Edition</h3>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-500/40">
                PWA APK
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Run TechCompare AI natively with 3D UI on your Android phone
            </p>
          </div>
        </div>

        {/* Features List */}
        <div className="bg-slate-900/90 rounded-xl p-4 border border-slate-800 space-y-2.5 text-xs text-slate-300">
          <div className="flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Standalone full-screen AMOLED Android 3D UI</span>
          </div>
          <div className="flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Instant silicon benchmark telemetry & offline spec cache</span>
          </div>
          <div className="flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Tactile Material Design 3 haptic vibration engine</span>
          </div>
          <div className="flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Gemini 3.7 & 3.1 Live Hardware AI Copilot</span>
          </div>
        </div>

        {/* Action Button or Instructions */}
        <button
          onClick={handleInstallClick}
          className="w-full py-3 px-4 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-sm rounded-xl shadow-[0_0_20px_rgba(16,185,129,0.4)] transition-all flex items-center justify-center space-x-2 cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>Download Android APK / Install PWA</span>
        </button>

        {showManualInstructions && (
          <div className="p-3 bg-red-950/40 border border-red-500/50 rounded-xl text-red-200 text-xs text-center animate-pulse">
            Automatic installation is blocked in this browser. Please follow the manual steps below.
          </div>
        )}

        {isIframe && (
          <div className="p-3 bg-amber-950/40 border border-amber-500/50 rounded-xl text-amber-200 text-xs text-center">
            <strong>Note:</strong> You are currently viewing this app inside a preview window. To install it, please open the app in a <strong>New Tab</strong> first.
          </div>
        )}

        {!deferredPrompt && (
          <div className="p-3.5 bg-cyan-950/30 border border-cyan-500/30 rounded-xl space-y-1.5 mt-3">
            <span className="text-xs font-bold text-cyan-300 block">
              How to install on Android Chrome / Browser:
            </span>
            <ol className="text-xs text-slate-300 list-decimal list-inside space-y-1">
              <li>Tap the three dots (<strong>⋮</strong>) in the top-right corner of Chrome.</li>
              <li>Select <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</li>
              <li>Launch anytime from your Android home screen like a native app!</li>
            </ol>
          </div>
        )}

        <div className="text-center">
          <button
            onClick={onClose}
            className="text-xs text-slate-500 hover:text-slate-300 font-semibold cursor-pointer"
          >
            Got it, continue in browser
          </button>
        </div>
      </div>
    </div>
  );
}
