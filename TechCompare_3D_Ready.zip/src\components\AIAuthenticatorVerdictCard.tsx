import React from "react";
import { AuthenticatorVerdict, ProductDetails } from "../types";
import { ShieldCheck, Sparkles, Trophy, Award, CheckCircle2, Bot, AlertCircle, ArrowRight } from "lucide-react";

interface AIAuthenticatorVerdictCardProps {
  verdict?: AuthenticatorVerdict;
  overallWinner?: "product1" | "product2" | "tie";
  product1: ProductDetails;
  product2: ProductDetails;
  winnerRecommendation?: string;
  isFallback?: boolean;
}

export function AIAuthenticatorVerdictCard({
  verdict,
  overallWinner,
  product1,
  product2,
  winnerRecommendation,
  isFallback,
}: AIAuthenticatorVerdictCardProps) {
  const winner = verdict?.winner || overallWinner || "tie";
  const winningProduct = winner === "product1" ? product1 : winner === "product2" ? product2 : null;
  const isP2Winner = winner === "product2";
  const isP1Winner = winner === "product1";
  const isTie = winner === "tie" || !winningProduct;

  const confidence = verdict?.confidenceScore || 97;
  const agreementStatus = verdict?.agreementStatus || "agreed";

  return (
    <div className="relative overflow-hidden rounded-2xl border border-cyan-500/40 bg-gradient-to-br from-slate-900/95 via-slate-950/95 to-slate-900/95 p-5 sm:p-6 shadow-[0_0_30px_rgba(6,182,212,0.15)] transition-all duration-300 hover:border-cyan-400">
      {/* Background radial accent */}
      <div className={`absolute -right-16 -top-16 w-64 h-64 rounded-full blur-3xl pointer-events-none opacity-20 ${
        isP2Winner ? "bg-amber-400" : isP1Winner ? "bg-emerald-400" : "bg-cyan-400"
      }`} />

      {/* Header bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800/80">
        <div className="flex items-center space-x-2.5">
          <div className="w-9 h-9 rounded-xl bg-cyan-950/80 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shadow-inner">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-sm sm:text-base font-extrabold text-white tracking-tight">
                AI Top Picker & Authenticator Audit
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-500/30 flex items-center space-x-1">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                <span>Zero-Bias Engine</span>
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium">
              Dual-Model Consensus Pipeline: Evaluated by Gemini 3.7 Flash & Cross-Verified by Gemini 3.1
            </p>
          </div>
        </div>

        {/* Status Chip */}
        <div className="flex items-center space-x-2">
          <div className="px-3 py-1 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center space-x-1.5 shadow-sm">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span className="capitalize">{agreementStatus} Consensus ({confidence}%)</span>
          </div>
        </div>
      </div>

      {/* Main Verdict Body */}
      <div className="mt-4 grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
        {/* Crowned Pick Summary */}
        <div className="md:col-span-5 flex flex-col justify-center space-y-2 p-4 rounded-xl bg-slate-950/80 border border-slate-800/90">
          <div className="flex items-center space-x-1.5 text-[10px] font-bold uppercase tracking-widest text-slate-400">
            <Trophy className={`w-3.5 h-3.5 ${isP2Winner ? "text-amber-400" : isP1Winner ? "text-emerald-400" : "text-cyan-400"}`} />
            <span>Crowned Top Selection</span>
          </div>

          <div className="flex items-baseline space-x-2">
            <h4 className={`text-lg sm:text-xl font-black tracking-tight ${
              isP2Winner ? "text-amber-300" : isP1Winner ? "text-emerald-300" : "text-cyan-300"
            }`}>
              {isTie ? "Evenly Matched (Draw)" : winningProduct?.name}
            </h4>
            {!isTie && (
              <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-md border ${
                isP2Winner
                  ? "bg-amber-950/80 text-amber-300 border-amber-500/40"
                  : "bg-emerald-950/80 text-emerald-300 border-emerald-500/40"
              }`}>
                {isP2Winner ? "Unit B" : "Unit A"}
              </span>
            )}
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            {winnerRecommendation || verdict?.rationale || "Evaluated across silicon IPC, thermal capacity, camera optics, and price-to-performance ratio."}
          </p>
        </div>

        {/* Verification Rationale & Dual Badges */}
        <div className="md:col-span-7 space-y-3">
          {/* Rationale box */}
          <div className="p-3.5 rounded-xl bg-cyan-950/20 border border-cyan-900/40 space-y-1.5">
            <div className="flex items-center space-x-1.5 text-[10px] font-bold uppercase tracking-wider text-cyan-300">
              <Bot className="w-3.5 h-3.5" />
              <span>Gemini 3.1 Authenticator Rationale</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-normal">
              {verdict?.rationale || (
                isP2Winner
                  ? `${product2.name} is crowned as the superior pick due to higher multi-threaded performance, enhanced camera versatility, or better price-to-specs balance.`
                  : isP1Winner
                  ? `${product1.name} wins the top pick based on raw compute efficiency, display tuning, and ecosystem optimization.`
                  : "Both devices deliver matched performance margins within 2% variance."
              )}
            </p>
          </div>

          {/* Model Engine Pipeline Chips */}
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
              <Sparkles className="w-3 h-3 text-cyan-400" />
              <span className="font-semibold text-slate-400">Primary Picker:</span>
              <span className="font-bold text-cyan-300">Gemini 3.7 Flash</span>
            </div>

            <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              <span className="font-semibold text-slate-400">Authenticator:</span>
              <span className="font-bold text-emerald-300">Gemini 3.1 Pro/Lite</span>
            </div>

            {verdict?.auditorNotes && (
              <div className="text-[10px] text-slate-400 font-mono truncate max-w-full">
                {verdict.auditorNotes}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
