import React, { useState, lazy } from "react";
import { ProductDetails } from "../types";
import { Trophy, Tag, Check, X, Sparkles, Cpu, Award, Zap, Shield } from "lucide-react";

const Device3DViewer = lazy(() => import("./Device3DViewer"));

interface ProductProfileCardProps {
  product: ProductDetails;
  isWinner: boolean;
  themeColor: "emerald" | "amber" | "blue" | "indigo";
}

export function ProductProfileCard({ product, isWinner, themeColor }: ProductProfileCardProps) {
  const [imgError, setImgError] = useState(false);
  const overallScore = product.radarScores.Overall || 0;
  const isAmber = themeColor === "amber" || themeColor === "indigo";

  const glowBorder = isWinner
    ? isAmber
      ? "border-amber-500/80 shadow-[0_0_30px_rgba(245,158,11,0.25),inset_0_1px_0_0_rgba(255,255,255,0.15)] ring-1 ring-amber-500/40"
      : "border-emerald-500/80 shadow-[0_0_30px_rgba(16,185,129,0.25),inset_0_1px_0_0_rgba(255,255,255,0.15)] ring-1 ring-emerald-500/40"
    : "border-slate-800/90 shadow-[0_20px_40px_rgba(0,0,0,0.8),inset_0_1px_0_0_rgba(255,255,255,0.08)] hover:border-slate-700";

  return (
    <div
      className={`relative bg-[#0d121f]/90 backdrop-blur-2xl border ${glowBorder} rounded-2xl p-6 relative flex flex-col justify-between transition-all duration-300 transform hover:-translate-y-1`}
    >
      {/* 3D Top Pick / Winner Ribbon */}
      {isWinner && (
        <div
          className={`absolute -top-3 left-6 text-slate-950 text-[10px] font-bold px-3.5 py-1.5 rounded-lg tracking-wide shadow-md flex flex-col space-y-0.5 z-10 transition-transform duration-200 hover:scale-105 ${
            isAmber
              ? "bg-amber-400 shadow-[0_0_15px_rgba(251,191,36,0.5)]"
              : "bg-emerald-400 shadow-[0_0_15px_rgba(52,211,153,0.5)]"
          }`}
        >
          <div className="flex items-center space-x-1.5 font-black uppercase">
            <Trophy className="w-3.5 h-3.5" />
            <span>Top Pick • Gemini 3.7</span>
          </div>
          <div className="text-[9px] opacity-90 font-semibold flex items-center space-x-1">
            <Check className="w-2.5 h-2.5" />
            <span>Verified by Gemini 3.1</span>
          </div>
        </div>
      )}

      <div>
        {/* 3D Holographic Product Media Box */}
        <div className="w-full h-52 mb-5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center p-0 relative overflow-hidden group shadow-inner">
          <React.Suspense fallback={
            <div className="flex flex-col items-center justify-center text-slate-500 space-y-2">
              <div className="w-8 h-8 border-2 border-slate-700 border-t-slate-400 rounded-full animate-spin" />
            </div>
          }>
            <Device3DViewer 
              productName={product.name}
              deviceType={product.deviceType || "phone"} 
              color={isAmber ? "#ff9b4d" : "#7cf5a0"} 
              screenColor="#0a0e14"
            />
          </React.Suspense>

          {/* Color marker tag */}
          <span
            className={`absolute top-2.5 left-2.5 text-[10px] font-bold px-2.5 py-0.5 rounded-md shadow-sm flex items-center space-x-1 border ${
              isAmber
                ? "bg-amber-950 text-amber-400 border-amber-500/30"
                : "bg-emerald-950 text-emerald-400 border-emerald-500/30"
            }`}
          >
            <span>{isAmber ? "Unit B" : "Unit A"}</span>
          </span>

          {/* Launch year badge */}
          {product.launchYear && (
            <span className="absolute bottom-2.5 right-2.5 text-[10px] font-bold px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-400 shadow-sm">
              {product.launchYear}
            </span>
          )}
        </div>

        {/* Title and Overall Rating */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div>
            {product.brand && (
              <span className="text-[11px] font-bold uppercase tracking-widest text-cyan-400">
                {product.brand}
              </span>
            )}
            <h3 className="text-lg sm:text-xl font-extrabold text-white leading-snug tracking-tight">
              {product.name}
            </h3>
          </div>

          {/* Rating Badge */}
          <div
            className={`flex flex-col items-center px-3.5 py-1.5 rounded-xl border shrink-0 shadow-lg ${
              isAmber
                ? "bg-amber-950/60 border-amber-500/40 text-amber-300 shadow-[0_0_15px_rgba(245,158,11,0.2)]"
                : "bg-emerald-950/60 border-emerald-500/40 text-emerald-300 shadow-[0_0_15px_rgba(16,185,129,0.2)]"
            }`}
          >
            <span className="text-2xl font-black leading-none">{overallScore}</span>
            <span className="text-[9px] uppercase font-bold tracking-widest opacity-80 mt-0.5">/10 Benchmark</span>
          </div>
        </div>

        {/* "Best For" summary pill */}
        {product.bestFor && (
          <div className="mb-4 inline-flex items-center space-x-2 px-3 py-2 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 font-medium w-full shadow-inner">
            <Award className={`w-4 h-4 shrink-0 ${isAmber ? "text-amber-400" : "text-emerald-400"}`} />
            <span className="truncate">
              <strong className="text-white">Ideal For:</strong> {product.bestFor}
            </span>
          </div>
        )}

        {/* Key Highlights */}
        {product.highlights && product.highlights.length > 0 && (
          <div className="mb-4">
            <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2 flex items-center space-x-1.5">
              <Sparkles className={`w-3 h-3 ${isAmber ? "text-amber-400" : "text-emerald-400"}`} />
              <span>Key Architectural Highlights</span>
            </h4>
            <div className="flex flex-wrap gap-1.5">
              {product.highlights.map((h, i) => (
                <span
                  key={i}
                  className="text-xs px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 font-medium hover:border-slate-700 transition-colors"
                >
                  {h}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Pros & Cons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4 pt-3 border-t border-slate-800">
          {product.pros && product.pros.length > 0 && (
            <div className="p-2.5 rounded-xl bg-emerald-950/20 border border-emerald-900/40 space-y-1.5">
              <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-400 flex items-center space-x-1">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Advantages</span>
              </span>
              <ul className="text-xs text-slate-300 space-y-1">
                {product.pros.slice(0, 3).map((pro, i) => (
                  <li key={i} className="flex items-start space-x-1.5">
                    <span className="text-emerald-400 font-bold">•</span>
                    <span className="leading-snug">{pro}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {product.cons && product.cons.length > 0 && (
            <div className="p-2.5 rounded-xl bg-rose-950/20 border border-rose-900/40 space-y-1.5">
              <span className="text-[10px] font-bold uppercase tracking-widest text-rose-400 flex items-center space-x-1">
                <X className="w-3.5 h-3.5 text-rose-400" />
                <span>Compromises</span>
              </span>
              <ul className="text-xs text-slate-300 space-y-1">
                {product.cons.slice(0, 3).map((con, i) => (
                  <li key={i} className="flex items-start space-x-1.5">
                    <span className="text-rose-400 font-bold">•</span>
                    <span className="leading-snug">{con}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>

      {/* Price Footer */}
      <div className="pt-4 border-t border-slate-800 mt-2 flex items-center justify-between">
        <div className="flex items-center space-x-2 text-white font-extrabold">
          <Tag className="w-4 h-4 text-emerald-400" />
          <span className="text-base sm:text-lg text-emerald-400 font-black tracking-tight">
            {product.price || "Price on Request"}
          </span>
        </div>
        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
          Market Target
        </span>
      </div>
    </div>
  );
}
