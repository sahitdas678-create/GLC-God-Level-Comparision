import React, { useState, useRef, useEffect } from "react";
import {
  Sparkles,
  Send,
  Bot,
  User,
  HelpCircle,
  Zap,
  Flame,
  BatteryCharging,
  Cpu,
  RefreshCw,
} from "lucide-react";
import { ProductDetails, ChatMessage } from "../types";

interface AICopilotChatProps {
  product1: ProductDetails;
  product2: ProductDetails;
}

export function AICopilotChat({ product1, product2 }: AICopilotChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "init",
      role: "assistant",
      content: `Hello! I am your AI Silicon & Hardware Architect. I have full telemetry and scanned specifications for both **${product1.name}** and **${product2.name}**.\n\nAsk me anything about real-world thermals, battery degradation curves, camera optics, emulation performance, or long-term OS support!`,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      suggestedPrompts: [
        `Which device handles heavy gaming & thermal throttling better?`,
        `How does low-light camera noise & shutter lag compare?`,
        `Which has longer battery endurance for video playback?`,
        `Is it worth the price difference between these two?`,
      ],
    },
  ]);

  const [inputQuery, setInputQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputQuery).trim();
    if (!query || loading) return;

    if (typeof navigator !== "undefined" && navigator.vibrate) {
      try {
        navigator.vibrate(10);
      } catch {
        // ignore
      }
    }

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      content: query,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuery("");
    setLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: query,
          product1,
          product2,
          history: messages.slice(-4),
        }),
      });

      if (!response.ok) throw new Error("Failed to get answer");

      const data = await response.json();
      const assistantMsg: ChatMessage = {
        id: `assistant-${Date.now()}`,
        role: "assistant",
        content: data.answer || "No response received.",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        suggestedPrompts: data.suggestedPrompts || [
          "Compare their thermal dissipation under 1 hour load",
          "Which holds higher resale value?",
        ],
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch {
      const fallbackMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: "assistant",
        content: `Between ${product1.name} and ${product2.name}, ${product1.name} delivers higher peak single-threaded performance with its ${product1.specs.processor}, whereas ${product2.name} offers competitive sustained battery endurance with its ${product2.specs.battery}.`,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setLoading(false);
    }
  };

  const quickTopics = [
    { label: "Gaming & FPS", icon: Zap, query: "How do these two devices compare for high frame-rate 3D gaming and thermal throttling?" },
    { label: "Thermals & Heat", icon: Flame, query: "Which device runs hotter under continuous heavy load and sustained rendering?" },
    { label: "Battery Under Load", icon: BatteryCharging, query: "Compare real-world battery drain when using 5G, GPS, and high brightness." },
    { label: "Silicon Architecture", icon: Cpu, query: "Explain the architectural difference between their CPU and GPU silicon cores." },
  ];

  return (
    <div className="relative bg-[#0d121f]/90 backdrop-blur-2xl border border-slate-800/90 rounded-2xl p-4 sm:p-6 shadow-[0_20px_40px_rgba(0,0,0,0.8),inset_0_1px_0_0_rgba(255,255,255,0.08)] flex flex-col h-[640px]">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800 shrink-0 mb-3">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-xl bg-cyan-950/80 border border-cyan-500/40 flex items-center justify-center shadow-[0_0_12px_rgba(6,182,212,0.3)]">
            <Sparkles className="w-4 h-4 text-cyan-400" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <span>AI Hardware Copilot</span>
              <span className="text-[10px] px-2 py-0.5 rounded-md bg-cyan-950 text-cyan-300 border border-cyan-500/40 font-mono">
                Gemini 3.7
              </span>
            </h3>
            <p className="text-[11px] text-slate-400">
              Live Q&A analyzing {product1.name} vs {product2.name}
            </p>
          </div>
        </div>

        <button
          onClick={() =>
            setMessages([
              {
                id: "init",
                role: "assistant",
                content: `Chat reset. What specific hardware or real-world comparison would you like to explore for ${product1.name} and ${product2.name}?`,
                timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
              },
            ])
          }
          className="text-xs text-slate-400 hover:text-white flex items-center space-x-1 p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          title="Reset Chat"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Reset</span>
        </button>
      </div>

      {/* Quick Topic Chips */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-2 mb-2 scrollbar-none shrink-0">
        {quickTopics.map((t, idx) => {
          const Icon = t.icon;
          return (
            <button
              key={idx}
              onClick={() => handleSendMessage(t.query)}
              disabled={loading}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-900/90 hover:bg-cyan-950/60 border border-slate-800 hover:border-cyan-500/40 text-slate-300 hover:text-cyan-300 text-[11px] font-semibold whitespace-nowrap transition-all cursor-pointer disabled:opacity-50 shadow-xs"
            >
              <Icon className="w-3 h-3 text-cyan-400 shrink-0" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto space-y-3.5 pr-1 py-1 scrollbar-thin">
        {messages.map((m) => {
          const isUser = m.role === "user";
          return (
            <div
              key={m.id}
              className={`flex items-start space-x-2.5 ${
                isUser ? "flex-row-reverse space-x-reverse" : "flex-row"
              }`}
            >
              <div
                className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 border ${
                  isUser
                    ? "bg-slate-800 text-white border-slate-700"
                    : "bg-cyan-950 text-cyan-300 border-cyan-500/40 shadow-[0_0_10px_rgba(6,182,212,0.3)]"
                }`}
              >
                {isUser ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
              </div>

              <div
                className={`max-w-[85%] sm:max-w-[78%] rounded-2xl px-4 py-3 text-xs sm:text-sm leading-relaxed ${
                  isUser
                    ? "bg-cyan-600 text-white rounded-tr-xs shadow-[0_0_15px_rgba(6,182,212,0.3)]"
                    : "bg-slate-900 text-slate-200 rounded-tl-xs border border-slate-800 shadow-inner"
                }`}
              >
                <div className="whitespace-pre-wrap">{m.content}</div>
                <div
                  className={`text-[9px] mt-1.5 text-right ${
                    isUser ? "text-cyan-200" : "text-slate-500"
                  }`}
                >
                  {m.timestamp}
                </div>

                {/* Suggested follow-up prompt chips */}
                {m.suggestedPrompts && m.suggestedPrompts.length > 0 && !loading && (
                  <div className="mt-3 pt-2.5 border-t border-slate-800 space-y-1.5">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                      Follow-up Questions:
                    </span>
                    <div className="flex flex-col space-y-1.5">
                      {m.suggestedPrompts.map((p, pIdx) => (
                        <button
                          key={pIdx}
                          onClick={() => handleSendMessage(p)}
                          className="text-left text-[11px] text-cyan-300 hover:text-white bg-slate-950/80 hover:bg-cyan-950/80 px-2.5 py-1.5 rounded-lg border border-slate-800 hover:border-cyan-500/40 transition-colors cursor-pointer flex items-center space-x-1.5"
                        >
                          <HelpCircle className="w-3 h-3 shrink-0 text-cyan-400" />
                          <span className="truncate">{p}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {loading && (
          <div className="flex items-start space-x-2.5">
            <div className="w-7 h-7 rounded-xl bg-cyan-950 text-cyan-300 border border-cyan-500/40 flex items-center justify-center shadow-xs">
              <Bot className="w-3.5 h-3.5" />
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-2xl rounded-tl-xs px-4 py-3 text-xs text-slate-300 flex items-center space-x-2.5">
              <div className="w-3.5 h-3.5 border-2 border-cyan-400/30 border-t-cyan-400 rounded-full animate-spin" />
              <span>Analyzing silicon benchmarks & telemetry...</span>
            </div>
          </div>
        )}
        <div ref={chatBottomRef} />
      </div>

      {/* Query Input Bar */}
      <div className="pt-3 border-t border-slate-800 shrink-0">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center space-x-2"
        >
          <input
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            placeholder={`Ask about ${product1.name.split(" ")[0]} vs ${product2.name.split(" ")[0]}...`}
            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-500/20 transition-all"
            disabled={loading}
          />
          <button
            type="submit"
            disabled={!inputQuery.trim() || loading}
            className="p-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-40 text-white rounded-xl shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-all cursor-pointer shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
