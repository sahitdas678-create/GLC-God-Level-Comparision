import React, { useState } from "react";
import {
  FileText,
  Cpu,
  Flame,
  Monitor,
  BatteryCharging,
  Camera,
  Weight,
  Layers,
  TrendingUp,
  UserCheck,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Zap,
  Globe,
  ExternalLink,
  ShieldCheck,
  Search,
} from "lucide-react";
import { ComparisonData } from "../types";

interface ResearchReportCardProps {
  comparisonData: ComparisonData;
}

export function ResearchReportCard({ comparisonData }: ResearchReportCardProps) {
  const { product1, product2, researchReport, searchSources, scannedLiveWeb, scannerEngine, verifierEngine, verifiedClaims } = comparisonData;
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    architecture: true,
    camera: true,
    battery: true,
    weight: true,
    os: true,
    thermals: true,
    display: true,
    buyer: true,
  });

  const toggleSection = (section: string) => {
    setExpandedSections((prev) => ({ ...prev, [section]: !prev[section] }));
  };

  if (!researchReport) {
    return null;
  }

  const reportSections = [
    {
      id: "architecture",
      title: "Microarchitecture & Compute Fabrics",
      subtitle: "CPU core topology, GPU microarchitecture & memory subsystem",
      icon: Cpu,
      content: researchReport.architectureAnalysis,
      tag: "Silicon Deep Dive",
    },
    {
      id: "camera",
      title: "Camera Sensors, Optics & Computational Imaging",
      subtitle: "Megapixels, optical zoom focal lengths, ultra-wide & ISP engines",
      icon: Camera,
      content: `• ${product1.name}: ${product1.specs.camera}\n• ${product2.name}: ${product2.specs.camera}\n\nComparative Camera Assessment: High-resolution sensors capture intricate optical detail and allow lossless in-sensor cropping, while advanced telephoto and periscope optics provide dedicated long-range magnification. Computational photography pipelines and neural image processors handle low-light HDR fusion and cinematic video stabilization.`,
      tag: "Optics & Imaging",
    },
    {
      id: "battery",
      title: "Energy Efficiency, Battery & Power Delivery",
      subtitle: "Watt-hour/mAh capacity, charging wattage & power draw curves",
      icon: BatteryCharging,
      content: `${researchReport.batteryAndEfficiency}\n\n• Detailed Specs:\n  - ${product1.name}: ${product1.specs.battery}\n  - ${product2.name}: ${product2.specs.battery}`,
      tag: "Power Dynamics",
    },
    {
      id: "weight",
      title: "Chassis Materials, Weight & Ergonomics",
      subtitle: "Structural mass, materials (Titanium/Aluminum/Glass) and daily portability",
      icon: Weight,
      content: `• ${product1.name}: ${product1.specs.weight}\n• ${product2.name}: ${product2.specs.weight}\n\nErgonomic Analysis: Chassis construction material significantly dictates structural rigidity, scratch resistance, and handheld center-of-gravity balance. Lighter builds reduce fatigue during one-handed usage and mobile commuting, while dense structural frames improve thermal heat-sinking.`,
      tag: "Portability & Build",
    },
    {
      id: "os",
      title: "Operating System, Ecosystem & Software Lifespan",
      subtitle: "OS platform, ecosystem cross-device continuity & guaranteed update roadmap",
      icon: Layers,
      content: `• ${product1.name}: ${product1.specs.os}\n• ${product2.name}: ${product2.specs.os}\n\nPlatform Comparison: Operating systems define file management flexibility, background multitasking capabilities, desktop-class app ecosystems, and cloud synchronization across your phone, tablet, and workstation.`,
      tag: "OS & Ecosystem",
    },
    {
      id: "thermals",
      title: "Thermal Dissipation & Sustained Workloads",
      subtitle: "Acoustics, active fans vs fanless throttling under peak 100% stress",
      icon: Flame,
      content: researchReport.thermalAndSustainedLoad,
      tag: "Cooling & Throttling",
    },
    {
      id: "display",
      title: "Display, Audio & Sensory Capabilities",
      subtitle: "Color gamut, panel tech, refresh response & spatial acoustics",
      icon: Monitor,
      content: researchReport.displayAndMultimedia,
      tag: "Visuals & Audio",
    },
    {
      id: "buyer",
      title: "Target Persona & Upgrade Matrix",
      subtitle: "Detailed breakdown of which user profiles benefit most",
      icon: UserCheck,
      content: researchReport.whoShouldUpgrade,
      tag: "Buying Decision",
    },
  ];

  return (
    <div className="relative bg-[#0d121f]/90 backdrop-blur-2xl border border-slate-800/90 rounded-2xl overflow-hidden shadow-[0_20px_40px_rgba(0,0,0,0.8),inset_0_1px_0_0_rgba(255,255,255,0.08)]">
      {/* Header */}
      <div className="p-6 border-b border-slate-800 bg-slate-900/70">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 text-white flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.4)]">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center flex-wrap gap-2">
                <h3 className="text-base sm:text-lg font-extrabold text-white">
                  Hardware Intelligence Dossier
                </h3>
                {scannedLiveWeb ? (
                  <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-500/40 uppercase tracking-wider">
                    <Globe className="w-2.5 h-2.5 mr-1 text-emerald-400" />
                    Live Web Grounded
                  </span>
                ) : (
                  <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-500/40 uppercase tracking-wider">
                    <Sparkles className="w-2.5 h-2.5 mr-1 text-cyan-400" />
                    Deep Technical Synthesis
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Technical investigation comparing <span className="font-semibold text-emerald-400">{product1.name}</span> vs{" "}
                <span className="font-semibold text-amber-400">{product2.name}</span>
              </p>
            </div>
          </div>

          {/* Dual Engine Audit Badges */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-lg bg-slate-950 border border-cyan-500/30 text-cyan-300 text-[11px] font-semibold shadow-inner">
              <Search className="w-3 h-3 text-cyan-400" />
              <span>{scannerEngine || "Gemini 3.7 Deep Tech Scanner"}</span>
            </div>
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-lg bg-slate-950 border border-emerald-500/30 text-emerald-300 text-[11px] font-semibold shadow-inner">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              <span>{verifierEngine || "Gemini 3.1 Verification & Cross-Checker"}</span>
            </div>
          </div>
        </div>

        {/* Verified Claims Bar */}
        {verifiedClaims && verifiedClaims.length > 0 && (
          <div className="mt-5 pt-4 border-t border-slate-800">
            <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-400 block mb-2.5 flex items-center space-x-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Gemini 3.1 Audited & Verified Specifications</span>
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {verifiedClaims.map((claim, idx) => (
                <div
                  key={idx}
                  className="flex items-start space-x-2 p-2.5 rounded-xl bg-emerald-950/20 border border-emerald-800/40 text-xs text-emerald-200"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                  <span className="leading-snug font-medium">{claim}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Key Differences Highlight Bar */}
        {researchReport.keyDifferences && researchReport.keyDifferences.length > 0 && (
          <div className="mt-4 pt-4 border-t border-slate-800">
            <span className="text-[10px] font-bold uppercase tracking-widest text-cyan-400 block mb-2 flex items-center space-x-1.5">
              <Zap className="w-3 h-3 text-amber-400" />
              <span>Critical Technical Differentiators</span>
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {researchReport.keyDifferences.map((diff, idx) => (
                <div
                  key={idx}
                  className="flex items-start space-x-2 p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 text-xs text-slate-300 shadow-sm"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                  <span className="leading-snug">{diff}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Live Search Sources if present */}
        {searchSources && searchSources.length > 0 && (
          <div className="mt-3 pt-3 border-t border-slate-800">
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 block mb-1.5 flex items-center space-x-1">
              <Globe className="w-3 h-3 text-cyan-400" />
              <span>Web Sources & Grounding Queries Scanned</span>
            </span>
            <div className="flex flex-wrap gap-1.5">
              {searchSources.map((src, i) => (
                <div
                  key={i}
                  className="inline-flex items-center space-x-1 px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-[11px] text-slate-300"
                >
                  <span className="font-medium truncate max-w-xs">{src.title}</span>
                  {src.url && (
                    <a
                      href={src.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-cyan-400 hover:text-cyan-300 ml-1"
                    >
                      <ExternalLink className="w-2.5 h-2.5" />
                    </a>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Sections list */}
      <div className="divide-y divide-slate-800/80 p-4 sm:p-6 space-y-3">
        {reportSections.map((sec) => {
          const IconComponent = sec.icon;
          const isExpanded = expandedSections[sec.id] !== false;

          return (
            <div
              key={sec.id}
              className="rounded-xl border border-slate-800/90 overflow-hidden bg-slate-900/60 transition-all hover:border-slate-700"
            >
              <button
                onClick={() => toggleSection(sec.id)}
                className="w-full p-4 flex items-center justify-between text-left hover:bg-slate-800/50 transition-colors cursor-pointer"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-center text-cyan-400 shrink-0">
                    <IconComponent className="w-4 h-4 text-cyan-400" />
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <h4 className="text-sm font-bold text-white">{sec.title}</h4>
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-800 text-slate-300 uppercase tracking-wide">
                        {sec.tag}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">{sec.subtitle}</p>
                  </div>
                </div>

                <div className="text-slate-400 pl-2">
                  {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </div>
              </button>

              {isExpanded && (
                <div className="p-4 pt-2 border-t border-slate-800 bg-slate-950/60">
                  <div className="prose prose-invert max-w-none text-slate-300 text-xs sm:text-sm leading-relaxed whitespace-pre-line">
                    {sec.content}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Footer summary */}
      {researchReport.valueAndDepreciation && (
        <div className="p-5 bg-slate-900/80 border-t border-slate-800 flex items-start space-x-3 text-xs text-slate-300">
          <TrendingUp className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <div>
            <strong className="text-white font-bold block mb-0.5">Value Retention & Longevity Index:</strong>
            <p className="leading-relaxed text-slate-400">{researchReport.valueAndDepreciation}</p>
          </div>
        </div>
      )}
    </div>
  );
}
