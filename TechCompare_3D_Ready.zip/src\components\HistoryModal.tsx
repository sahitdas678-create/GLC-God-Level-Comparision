import { ComparisonHistoryItem } from "../types";
import { History, Trash2, ArrowRight, X, Clock } from "lucide-react";

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  history: ComparisonHistoryItem[];
  onSelect: (item: ComparisonHistoryItem) => void;
  onClear: () => void;
}

export function HistoryModal({
  isOpen,
  onClose,
  history,
  onSelect,
  onClear,
}: HistoryModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-[#0d121f] border border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-[0_25px_60px_rgba(0,0,0,0.9)] relative">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-950/80 border border-cyan-500/40 flex items-center justify-center shadow-[0_0_10px_rgba(6,182,212,0.3)]">
              <History className="w-4 h-4 text-cyan-400" />
            </div>
            <h3 className="text-base font-extrabold text-white">Comparison History</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {history.length === 0 ? (
          <div className="py-12 text-center text-slate-500">
            <Clock className="w-10 h-10 mx-auto mb-2 opacity-40 text-slate-400" />
            <p className="text-sm">No recent comparisons yet.</p>
          </div>
        ) : (
          <>
            <div className="max-h-80 overflow-y-auto space-y-2 pr-1 mb-4 scrollbar-thin">
              {history.map((item) => (
                <div
                  key={item.id}
                  onClick={() => {
                    onSelect(item);
                    onClose();
                  }}
                  className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-cyan-500/40 hover:bg-slate-850 cursor-pointer transition-all flex items-center justify-between group shadow-sm"
                >
                  <div>
                    <div className="flex items-center space-x-2 text-sm font-bold text-white">
                      <span className="text-emerald-400">{item.product1Name}</span>
                      <span className="text-slate-500 text-xs font-bold">vs</span>
                      <span className="text-amber-400">{item.product2Name}</span>
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5 font-medium">
                      {item.region} • {new Date(item.timestamp).toLocaleDateString()}
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-cyan-400 group-hover:translate-x-0.5 transition-all" />
                </div>
              ))}
            </div>

            <div className="flex justify-between items-center pt-3.5 border-t border-slate-800">
              <button
                onClick={onClear}
                className="text-xs text-rose-400 hover:text-rose-300 font-semibold flex items-center space-x-1.5 transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear All History</span>
              </button>
              <button
                onClick={onClose}
                className="px-4 py-1.5 rounded-xl bg-slate-900 border border-slate-700 hover:bg-slate-800 text-slate-200 text-xs font-semibold transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
