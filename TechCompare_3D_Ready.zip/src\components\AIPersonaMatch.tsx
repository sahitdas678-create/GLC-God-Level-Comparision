import React, { useState, useEffect } from "react";
import {
  Gamepad2,
  Video,
  Code2,
  Briefcase,
  GraduationCap,
  Sparkles,
  Trophy,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  Target,
} from "lucide-react";
import { ProductDetails, PersonaMatchResult, PersonaProfile } from "../types";

interface AIPersonaMatchProps {
  product1: ProductDetails;
  product2: ProductDetails;
}

const PERSONAS: PersonaProfile[] = [
  {
    id: "gamer",
    title: "Pro Gamer & Emulation",
    subtitle: "Focus on GPU compute, 120Hz display latency, and cooling",
    iconName: "gamepad",
    prioritySpecs: ["gpu", "refreshRate", "fan", "processor"],
  },
  {
    id: "creator",
    title: "4K Creator & Editor",
    subtitle: "Focus on color accuracy, camera sensors, and fast storage",
    iconName: "video",
    prioritySpecs: ["camera", "display", "storage", "ram"],
  },
  {
    id: "coder",
    title: "Software Engineer",
    subtitle: "Focus on CPU multicore compilation, RAM headroom, and OS",
    iconName: "code",
    prioritySpecs: ["processor", "ram", "cores", "os"],
  },
  {
    id: "executive",
    title: "Traveler & Battery Warrior",
    subtitle: "Focus on battery life, low weight, and durability",
    iconName: "briefcase",
    prioritySpecs: ["battery", "weight", "os"],
  },
  {
    id: "student",
    title: "Student & Everyday Value",
    subtitle: "Focus on price-to-performance, screen quality, and longevity",
    iconName: "student",
    prioritySpecs: ["price", "display", "battery", "os"],
  },
];

export function AIPersonaMatch({ product1, product2 }: AIPersonaMatchProps) {
  const [selectedPersona, setSelectedPersona] = useState<string>("gamer");
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<Record<string, PersonaMatchResult>>({});

  const fetchPersonaAnalysis = async (personaId: string) => {
    if (results[personaId]) return;
    setLoading(true);

    try {
      const res = await fetch("/api/persona-match", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          personaId,
          product1,
          product2,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setResults((prev) => ({ ...prev, [personaId]: data }));
      }
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPersonaAnalysis(selectedPersona);
  }, [selectedPersona, product1.name, product2.name]);

  const activeResult = results[selectedPersona];

  const getPersonaIcon = (id: string) => {
    switch (id) {
      case "gamer":
        return Gamepad2;
      case "creator":
        return Video;
      case "coder":
        return Code2;
      case "executive":
        return Briefcase;
      case "student":
        return GraduationCap;
      default:
        return Target;
    }
  };

  return (
    <div className="relative bg-[#0d121f]/90 backdrop-blur-2xl border border-slate-800/90 rounded-2xl p-4 sm:p-6 shadow-[0_20px_40px_rgba(0,0,0,0.8),inset_0_1px_0_0_rgba(255,255,255,0.08)] space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-950/80 border border-emerald-500/40 flex items-center justify-center shadow-[0_0_12px_rgba(16,185,129,0.3)]">
              <Target className="w-4 h-4 text-emerald-400" />
            </div>
            <h3 className="text-base font-extrabold text-white">
              AI Persona & Workload Matcher
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Simulate compatibility scores and custom bottleneck warnings tailored to your exact use case
          </p>
        </div>

        <button
          onClick={() => {
            setResults({});
            fetchPersonaAnalysis(selectedPersona);
          }}
          disabled={loading}
          className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-800 hover:border-slate-700 transition-all cursor-pointer disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
          <span>Recalculate Fit</span>
        </button>
      </div>

      {/* Persona Selection Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
        {PERSONAS.map((p) => {
          const Icon = getPersonaIcon(p.id);
          const isSelected = selectedPersona === p.id;
          return (
            <button
              key={p.id}
              onClick={() => setSelectedPersona(p.id)}
              className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                isSelected
                  ? "bg-cyan-950 border-cyan-400 text-cyan-100"
                  : "bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800 hover:border-slate-700"
              }`}
            >
              <div className="mb-2">
                <Icon className={`w-5 h-5 ${isSelected ? "text-cyan-400" : "text-slate-500"}`} />
              </div>
              <div>
                <span className="text-xs font-bold block leading-tight">{p.title}</span>
                <span
                  className={`text-[10px] line-clamp-1 mt-0.5 ${
                    isSelected ? "text-cyan-300" : "text-slate-500"
                  }`}
                >
                  {p.subtitle}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Workload Match Results */}
      {loading && !activeResult ? (
        <div className="py-12 flex flex-col items-center justify-center space-y-3 bg-slate-900/80 rounded-xl border border-slate-800">
          <div className="w-8 h-8 border-3 border-cyan-400/30 border-t-cyan-400 rounded-full animate-spin" />
          <p className="text-xs font-medium text-slate-400">
            Analyzing hardware bottlenecks for this profile...
          </p>
        </div>
      ) : activeResult ? (
        <div className="space-y-4">
          {/* Fit Scores Comparison */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Product 1 Card */}
            <div
              className={`p-4 rounded-xl border transition-all ${
                activeResult.winner === "product1"
                  ? "bg-emerald-950/50 border-emerald-500/60 ring-1 ring-emerald-500/40"
                  : "bg-slate-900 border-slate-800"
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-bold text-white truncate">
                  {product1.name}
                </h4>
                {activeResult.winner === "product1" && (
                  <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-md bg-emerald-500 text-slate-950 text-[10px] font-extrabold shadow-sm">
                    <Trophy className="w-3 h-3" />
                    <span>Top Match</span>
                  </span>
                )}
              </div>

              {/* Progress score */}
              <div className="space-y-1.5 my-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-medium">Workload Compatibility</span>
                  <span className="font-extrabold text-emerald-400 text-sm">{activeResult.p1Score}%</span>
                </div>
                <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className="h-full bg-emerald-400 rounded-full transition-all duration-500"
                    style={{ width: `${activeResult.p1Score}%` }}
                  />
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed mt-2">
                {activeResult.p1Verdict}
              </p>
            </div>

            {/* Product 2 Card */}
            <div
              className={`p-4 rounded-xl border transition-all ${
                activeResult.winner === "product2"
                  ? "bg-amber-950/50 border-amber-500/60 ring-1 ring-amber-500/40"
                  : "bg-slate-900 border-slate-800"
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-bold text-white truncate">
                  {product2.name}
                </h4>
                {activeResult.winner === "product2" && (
                  <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-md bg-amber-500 text-slate-950 text-[10px] font-extrabold shadow-sm">
                    <Trophy className="w-3 h-3" />
                    <span>Top Match</span>
                  </span>
                )}
              </div>

              {/* Progress score */}
              <div className="space-y-1.5 my-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-medium">Workload Compatibility</span>
                  <span className="font-extrabold text-amber-400 text-sm">{activeResult.p2Score}%</span>
                </div>
                <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className="h-full bg-amber-400 rounded-full transition-all duration-500"
                    style={{ width: `${activeResult.p2Score}%` }}
                  />
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed mt-2">
                {activeResult.p2Verdict}
              </p>
            </div>
          </div>

          {/* Persona Recommendation & Bottlenecks */}
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3 shadow-inner">
            <div className="flex items-start space-x-2.5">
              <Sparkles className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <span className="text-xs font-bold text-white block mb-0.5">
                  AI Tailored Advice for this Persona
                </span>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {activeResult.recommendation}
                </p>
              </div>
            </div>

            {activeResult.keyBottlenecks && activeResult.keyBottlenecks.length > 0 && (
              <div className="pt-2.5 border-t border-slate-800">
                <div className="flex items-center space-x-1.5 text-slate-300 text-xs font-bold mb-2">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                  <span>Key Hardware Bottlenecks to Watch Out For:</span>
                </div>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {activeResult.keyBottlenecks.map((b, idx) => (
                    <li
                      key={idx}
                      className="text-xs text-slate-300 flex items-start space-x-2 bg-slate-950/80 p-2.5 rounded-lg border border-slate-800"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      ) : null}
    </div>
  );
}
