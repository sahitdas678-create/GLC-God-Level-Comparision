export interface ProductSpecs {
  processor: string;
  cores: string;
  ram: string;
  storage: string;
  gpu: string;
  display: string;
  refreshRate: string;
  fan: string;
  battery: string;
  camera: string;
  weight: string;
  os: string;
}

export interface RadarScores {
  Memory: number;
  Processing: number;
  Graphics: number;
  Display: number;
  Battery: number;
  Camera?: number;
  Portability?: number;
  Value: number;
  Overall: number;
}

export interface ProductDetails {
  name: string;
  deviceType?: "phone" | "laptop" | "tablet" | "watch" | "generic";
  brand?: string;
  imageUrl: string;
  price: string;
  launchYear?: string;
  highlights: string[];
  pros: string[];
  cons: string[];
  bestFor: string;
  specs: ProductSpecs;
  radarScores: RadarScores;
}

export interface ResearchReport {
  architectureAnalysis: string;
  thermalAndSustainedLoad: string;
  displayAndMultimedia: string;
  batteryAndEfficiency: string;
  valueAndDepreciation: string;
  whoShouldUpgrade: string;
  keyDifferences: string[];
}

export interface FeatureBreakdownItem {
  key: string;
  winner: 'product1' | 'product2' | 'tie';
  explanation: string;
  p1Advantage: string;
  p2Advantage: string;
  verifiedBy?: string;
}

export interface AuthenticatorVerdict {
  approved: boolean;
  winner: 'product1' | 'product2' | 'tie';
  winnerName?: string;
  rationale: string;
  confidenceScore: number;
  agreementStatus: 'agreed' | 'adjusted' | 'verified';
  auditorNotes?: string;
}

export interface ComparisonData {
  summary: string;
  winnerRecommendation: string;
  overallWinner?: 'product1' | 'product2' | 'tie';
  authenticatorVerdict?: AuthenticatorVerdict;
  product1: ProductDetails;
  product2: ProductDetails;
  specWinners?: {
    [key: string]: 'product1' | 'product2' | 'tie';
  };
  featureBreakdowns?: FeatureBreakdownItem[];
  researchReport?: ResearchReport;
  searchSources?: { title: string; url?: string }[];
  scannedLiveWeb?: boolean;
  scannerEngine?: string;
  verifierEngine?: string;
  verifiedClaims?: string[];
  isEstimatedFallback?: boolean;
  notice?: string;
}

export interface ComparisonHistoryItem {
  id: string;
  product1Name: string;
  product2Name: string;
  region: string;
  timestamp: number;
  data: ComparisonData;
}

export type AndroidTab = "overview" | "specs" | "report" | "copilot" | "camera" | "persona";

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  suggestedPrompts?: string[];
}

export interface PersonaProfile {
  id: string;
  title: string;
  subtitle: string;
  iconName: string;
  prioritySpecs: string[];
}

export interface PersonaMatchResult {
  personaId: string;
  p1Score: number;
  p2Score: number;
  p1Verdict: string;
  p2Verdict: string;
  winner: "product1" | "product2" | "tie";
  keyBottlenecks: string[];
  recommendation: string;
}

export interface CameraScenario {
  id: "night" | "zoom" | "portrait" | "hdr";
  title: string;
  badge: string;
  p1Metric: string;
  p2Metric: string;
  winner: "product1" | "product2" | "tie";
  analysis: string;
  p1Strengths: string;
  p2Strengths: string;
}
