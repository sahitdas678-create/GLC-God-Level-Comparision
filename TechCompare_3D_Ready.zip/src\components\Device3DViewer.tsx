import React, { useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { RoundedBox, Environment, ContactShadows, Text, Float } from '@react-three/drei';
import * as THREE from 'three';

const BaseDevice = ({ children, autoRotate = true }: { children: React.ReactNode, autoRotate?: boolean }) => {
  const group = useRef<THREE.Group>(null);
  const [hovered, setHovered] = useState(false);

  useFrame((state) => {
    if (group.current) {
      if (autoRotate && !hovered) {
        group.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.5) * 0.3;
        group.current.rotation.x = Math.cos(state.clock.elapsedTime * 0.3) * 0.1;
      } else if (hovered) {
        group.current.rotation.y = THREE.MathUtils.lerp(group.current.rotation.y, (state.mouse.x * Math.PI) / 4, 0.1);
        group.current.rotation.x = THREE.MathUtils.lerp(group.current.rotation.x, -(state.mouse.y * Math.PI) / 4, 0.1);
      }
    }
  });

  return (
    <group 
      ref={group}
      onPointerOver={(e) => { e.stopPropagation(); setHovered(true); }}
      onPointerOut={(e) => { e.stopPropagation(); setHovered(false); }}
    >
      <Float speed={2} rotationIntensity={0.2} floatIntensity={0.5}>
        {children}
      </Float>
    </group>
  );
};

const PhoneModel = ({ color = "#1e293b", screenColor = "#0f172a", brand = "Device" }: { color?: string; screenColor?: string; brand?: string; }) => (
  <BaseDevice>
    {/* Main Body */}
    <RoundedBox args={[3, 6, 0.4]} radius={0.3} smoothness={4}>
      <meshStandardMaterial color={color} roughness={0.2} metalness={0.8} />
    </RoundedBox>

    {/* Screen */}
    <RoundedBox args={[2.8, 5.7, 0.41]} radius={0.2} smoothness={4} position={[0, 0, 0.01]}>
      <meshStandardMaterial color={screenColor} roughness={0.1} metalness={0.9} />
    </RoundedBox>

    {/* Screen Content (Abstract UI) */}
    <mesh position={[0, 2, 0.22]}>
      <planeGeometry args={[2.5, 1]} />
      <meshBasicMaterial color="#35d8f0" transparent opacity={0.1} />
    </mesh>
    <mesh position={[0, 0.5, 0.22]}>
      <planeGeometry args={[2.5, 1.5]} />
      <meshBasicMaterial color="#35d8f0" transparent opacity={0.05} />
    </mesh>

    {/* Camera Bump */}
    <RoundedBox args={[1.2, 1.2, 0.45]} radius={0.2} smoothness={4} position={[-0.7, 2, -0.05]}>
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.9} />
    </RoundedBox>
    <mesh position={[-0.7, 2.2, -0.1]} rotation={[Math.PI / 2, 0, 0]}>
      <cylinderGeometry args={[0.2, 0.2, 0.5, 32]} />
      <meshStandardMaterial color="#000000" roughness={0} metalness={1} />
    </mesh>
    <mesh position={[-0.7, 1.7, -0.1]} rotation={[Math.PI / 2, 0, 0]}>
      <cylinderGeometry args={[0.2, 0.2, 0.5, 32]} />
      <meshStandardMaterial color="#000000" roughness={0} metalness={1} />
    </mesh>

    {/* Brand Text */}
    <Text position={[0, -2, 0.22]} fontSize={0.2} color="#35d8f0" anchorX="center" anchorY="middle" fillOpacity={0.8}>
      {brand}
    </Text>
  </BaseDevice>
);

const TabletModel = ({ color = "#1e293b", screenColor = "#0f172a", brand = "Tablet" }: { color?: string; screenColor?: string; brand?: string; }) => (
  <BaseDevice>
    {/* Main Body */}
    <RoundedBox args={[4.5, 6, 0.3]} radius={0.2} smoothness={4}>
      <meshStandardMaterial color={color} roughness={0.2} metalness={0.8} />
    </RoundedBox>

    {/* Screen */}
    <RoundedBox args={[4.2, 5.7, 0.31]} radius={0.15} smoothness={4} position={[0, 0, 0.01]}>
      <meshStandardMaterial color={screenColor} roughness={0.1} metalness={0.9} />
    </RoundedBox>

    <mesh position={[0, 1.5, 0.16]}>
      <planeGeometry args={[3.8, 2]} />
      <meshBasicMaterial color="#35d8f0" transparent opacity={0.1} />
    </mesh>

    {/* Camera Bump (centered usually on tablets or corner) */}
    <mesh position={[-1.7, 2.4, -0.1]} rotation={[Math.PI / 2, 0, 0]}>
      <cylinderGeometry args={[0.15, 0.15, 0.4, 32]} />
      <meshStandardMaterial color="#000000" roughness={0} metalness={1} />
    </mesh>

    {/* Brand Text */}
    <Text position={[0, -2.5, 0.16]} fontSize={0.2} color="#35d8f0" anchorX="center" anchorY="middle" fillOpacity={0.8}>
      {brand}
    </Text>
  </BaseDevice>
);

const LaptopModel = ({ color = "#1e293b", screenColor = "#0f172a", brand = "Laptop" }: { color?: string; screenColor?: string; brand?: string; }) => (
  <BaseDevice>
    {/* Base */}
    <RoundedBox args={[6, 0.2, 4]} radius={0.05} smoothness={4} position={[0, -1, 1]}>
      <meshStandardMaterial color={color} roughness={0.2} metalness={0.8} />
    </RoundedBox>
    
    {/* Keyboard Area */}
    <mesh position={[0, -0.89, 0.5]} rotation={[-Math.PI / 2, 0, 0]}>
      <planeGeometry args={[5, 2]} />
      <meshStandardMaterial color="#0a0a0a" roughness={0.8} metalness={0.2} />
    </mesh>

    {/* Trackpad */}
    <mesh position={[0, -0.89, 2.2]} rotation={[-Math.PI / 2, 0, 0]}>
      <planeGeometry args={[2, 1]} />
      <meshStandardMaterial color={color} roughness={0.4} metalness={0.5} />
    </mesh>

    {/* Lid */}
    <group position={[0, -1, -1]} rotation={[-0.2, 0, 0]}>
      <RoundedBox args={[6, 4, 0.15]} radius={0.05} smoothness={4} position={[0, 2, 0]}>
        <meshStandardMaterial color={color} roughness={0.2} metalness={0.8} />
      </RoundedBox>
      {/* Screen */}
      <RoundedBox args={[5.7, 3.7, 0.16]} radius={0.05} smoothness={4} position={[0, 2, 0.01]}>
        <meshStandardMaterial color={screenColor} roughness={0.1} metalness={0.9} />
      </RoundedBox>
      <mesh position={[0, 2, 0.1]}>
        <planeGeometry args={[5, 3]} />
        <meshBasicMaterial color="#35d8f0" transparent opacity={0.1} />
      </mesh>
      {/* Brand Text on back of lid */}
      <Text position={[0, 2, -0.08]} rotation={[0, Math.PI, 0]} fontSize={0.4} color="#35d8f0" anchorX="center" anchorY="middle" fillOpacity={0.8}>
        {brand}
      </Text>
    </group>
  </BaseDevice>
);

const WatchModel = ({ color = "#1e293b", screenColor = "#0f172a", brand = "Watch" }: { color?: string; screenColor?: string; brand?: string; }) => (
  <BaseDevice>
    {/* Watch Face / Body */}
    <RoundedBox args={[1.5, 1.8, 0.4]} radius={0.3} smoothness={4}>
      <meshStandardMaterial color={color} roughness={0.2} metalness={0.8} />
    </RoundedBox>
    {/* Screen */}
    <RoundedBox args={[1.3, 1.6, 0.41]} radius={0.25} smoothness={4} position={[0, 0, 0.01]}>
      <meshStandardMaterial color={screenColor} roughness={0.1} metalness={0.9} />
    </RoundedBox>
    {/* Straps */}
    <mesh position={[0, 1.5, -0.1]} rotation={[0.2, 0, 0]}>
      <boxGeometry args={[1.2, 2, 0.1]} />
      <meshStandardMaterial color="#111" roughness={0.8} />
    </mesh>
    <mesh position={[0, -1.5, -0.1]} rotation={[-0.2, 0, 0]}>
      <boxGeometry args={[1.2, 2, 0.1]} />
      <meshStandardMaterial color="#111" roughness={0.8} />
    </mesh>
    {/* Brand Text */}
    <Text position={[0, 0, 0.22]} fontSize={0.15} color="#35d8f0" anchorX="center" anchorY="middle" fillOpacity={0.8}>
      {brand}
    </Text>
  </BaseDevice>
);

const GenericModel = ({ color = "#1e293b", brand = "Device" }: { color?: string; brand?: string; }) => (
  <BaseDevice>
    {/* Generic Abstract Cube */}
    <RoundedBox args={[3, 3, 3]} radius={0.4} smoothness={4}>
      <meshStandardMaterial color={color} roughness={0.2} metalness={0.8} />
    </RoundedBox>
    {/* Brand Text */}
    <Text position={[0, 0, 1.51]} fontSize={0.4} color="#35d8f0" anchorX="center" anchorY="middle" fillOpacity={0.8}>
      {brand}
    </Text>
  </BaseDevice>
);

export default function Device3DViewer({ 
  productName, 
  deviceType = "phone",
  color = "#1e293b", 
  screenColor = "#0f172a" 
}: { 
  productName: string;
  deviceType?: "phone" | "laptop" | "tablet" | "watch" | "generic";
  color?: string;
  screenColor?: string;
}) {
  const brand = productName.split(' ')[0];

  return (
    <div className="w-full h-full cursor-grab active:cursor-grabbing transition-transform duration-500 group-hover:scale-105">
      <Canvas camera={{ position: [0, 0, deviceType === 'laptop' ? 10 : 8], fov: 45 }}>
        <ambientLight intensity={0.5} />
        <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} castShadow />
        <pointLight position={[-10, -10, -10]} intensity={0.5} />
        <Environment preset="city" />
        
        {deviceType === 'laptop' && <LaptopModel brand={brand} color={color} screenColor={screenColor} />}
        {deviceType === 'tablet' && <TabletModel brand={brand} color={color} screenColor={screenColor} />}
        {deviceType === 'watch' && <WatchModel brand={brand} color={color} screenColor={screenColor} />}
        {deviceType === 'phone' && <PhoneModel brand={brand} color={color} screenColor={screenColor} />}
        {deviceType === 'generic' && <GenericModel brand={brand} color={color} />}
        
        <ContactShadows position={[0, -4, 0]} opacity={0.4} scale={10} blur={2} far={4} />
      </Canvas>
    </div>
  );
}
